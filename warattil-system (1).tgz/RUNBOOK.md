# دليل التشغيل الآلي — قناة وَرَتِّل

This file is the operating procedure for the scheduled Claude sessions. Follow it exactly.
Never print, log or echo the values of YT_CLIENT_ID / YT_CLIENT_SECRET / YT_REFRESH_TOKEN.
Never reply to or delete comments, never change channel settings beyond what this file says,
never publish a video whose surah/ayahs were not stated by the reciter (the pipeline enforces this).

## Fixed IDs
- Control panel artifact (code bundle + database): CONTROL_URL (see routine prompt)
- Drive folders:
  - INBOX `15zj1STbX01XNR24ybu-7x7-M4DV3rnnf` (📥 تلاوات جديدة)
  - PROCESSED `1d0wssJLv3cgtQ4NfEP4Ermb1LxblOhuQ` (✅ تمت المعالجة — originals are kept here forever)
  - REVIEW `1ibpWuX5ZWkgTxS7CrD2EKvsQWa-GKr1g` (⚠️ تحتاج مراجعة)
  - REPORTS `1EjrjscDUpHQ2u0geooW-XEAaPpCaMWe_` (📊 التقارير الأسبوعية)

## 0. Bootstrap (both procedures)
The environment's setup script (configured by the owner) installs everything before the session starts:
code at /home/user/quran-channel, Python packages, the speech model and the background loops.
1. `cd /home/user/quran-channel && ls src/pipeline.py models/sherpa-onnx-whisper-small assets/brand/loop_h.mp4`
   If anything is missing, do not install or download anything yourself: finish with one Arabic line telling the owner the
   environment setup script did not run (they can re-save it in the environment settings).
2. `ArtifactData` get `system/config` on CONTROL_URL. If it exists, merge its fields into config.json
   (`python3 src/apply_config.py '<json>'`). This is how the owner's approved settings (publish mode, slots, reciter name) reach the run.
3. `python3 src/check_auth.py` → prints only whether the three YT_* variables are set and whether Google accepts them (never the values).

## Drive access
Prefer the Google Drive connector tools (search_files, download_file_content, update_file, create_file) when they are available in
the session. If they are not, use the same operations through the owner's OAuth token (it includes the drive scope):
`python3 src/drive.py list <folder>` · `download <id> <dest>` · `move <id> <new_parent>` · `upload_text <parent> <title> <file.md>`.

## A. Daily procedure (process new recitations)
1. If YouTube is NOT configured: do not process anything. Read `system/state`; if `reminded_unconfigured` is not today's date,
   finish with a one-line Arabic reminder that the YouTube connection is still pending, and set that field. Otherwise finish silently ("لا جديد").
1b. First connected run only: if `system/state.channel_setup_done` is not true, run `python3 src/channel_setup.py --check` then
   `python3 src/channel_setup.py` (description, keywords, country/language, banner, watermark, base playlists — the owner authorized
   this one-time setup). Save `{channel_setup_done:true, youtube_connected:true, channel_title, channel_url, setup:{...,oauth:true,channel:true}}`
   into `system/state`, and include in the final message the `manual` items it prints and any `failed` items.
2. List INBOX: `search_files` query `parentId = '15zj1STbX01XNR24ybu-7x7-M4DV3rnnf'`. Audio = mimeType audio/* or video/* or names ending
   .m4a .mp3 .wav .ogg .opus .aac .flac .mp4 .3gp .amr. Oldest first, at most 3 per run. None → finish silently with "لا جديد".
3. For each file:
   a. Name source: if the Drive file description is non-empty use it, else the file title.
   b. `download_file_content` (it is saved to a JSON file) → decode base64 `content` into `inbox/<id>.<ext>` with python `-I`.
      If the download fails because the file is too large, move it to REVIEW and report "الملف أكبر من حد التنزيل".
   c. `python3 src/pipeline.py process inbox/<id>.<ext> --name "<name source>"` — it prints one JSON line at the end and exits with:
      - 0 → done. `update_file` parentId=PROCESSED.
      - 3 (needs_info: surah/ayahs missing or invalid) → move to REVIEW. Notify: the file name and exactly what to write
        (e.g. «يس 1-12» or «الكهف كاملة») in the file name, then move it back to 📥.
      - 4 (audio rejected) → move to REVIEW, notify with the reason.
      - 5 (QA failed) → retry the same command once; if it fails again move to REVIEW and notify.
      - 6 (upload failed) → leave the file in INBOX; increment `attempts` on its db row; on the 3rd failure move to REVIEW and notify.
        If the error mentions invalid_grant / انتهت صلاحية → notify immediately: the YouTube authorization must be renewed.
        If status is `duplicate` → move to REVIEW and notify.
   d. Write `videos/<job_id>` on CONTROL_URL with ArtifactData `set`:
      `{job_id, created (ISO), source_name, drive_file_id, surah, surah_name, surah_ayahs, ayah_from, ayah_to, duration_min, status, long_url, long_title,
        short_url, publish_at, short_publish_at, privacy, warnings:[...], error, attempts}` (values from `jobs/<job_id>/job.json`).
4. Update `system/state` {last_daily_run (ISO), last_result, youtube_connected:true, channel_title} with `update` (or `set` if missing).
5. Final message (Arabic, short): what was published/scheduled with links, and ONLY the problems that need the owner.
   Warnings that need no action (e.g. noise reduced) go in the db row, not the message.

## B. Weekly procedure (report)
1. If YouTube is not configured → finish with one line saying the report cannot run until the connection is done.
2. Collect last 7 days of problems: ArtifactData `query` collection `videos` → rows whose status is not
   scheduled/published/uploaded_private, or that have warnings/attempts>0 → write as a JSON list of short Arabic strings
   to `reports/events.json` (each: date, file, problem, how it was resolved or "بانتظار إجراء").
3. `python3 src/report.py --events reports/events.json` → prints the .md path; also read the .json beside it.
4. Write the final report in Arabic from those files only. Required sections, in order:
   1) عدد الفيديوهات المنشورة 2) مشاهدات كل فيديو والإجمالي 3) وقت المشاهدة ومتوسط المدة 4) المشتركون المكتسبون
   5) أفضل 3 فيديوهات وأسباب تفوقها (from retention %, traffic sources, avg % viewed — say when data is too thin)
   6) الضعيفة وأسبابها المحتملة 7) المقارنة بالأسبوع السابق 8) أفضل أوقات النشر (days only from data; hours are not in the API)
   9) توصيات محددة للأسبوع القادم 10) جدول النشر المقترح (from config slots + files waiting in INBOX)
   11) الأخطاء وكيف عولجت 12) حالة تحقيق الربح. Never invent a number; write "غير متاح" with the reason from `notes`.
5. Save it to Drive: `create_file` title «تقرير وَرَتِّل الأسبوعي <end date>», parentId=REPORTS, textContent=<markdown>, contentMimeType=text/markdown.
6. ArtifactData `set` `reports/<end date>` {period:[start,end], period_end, views, watch_hours, avg_view_duration_sec, subs_gained, videos_published, doc_url, summary (≤600 chars)}.
7. Final message: the 5-line summary + the Drive link.

## C. On-demand procedure (the owner's chosen way of working)
The owner publishes occasionally, not on a schedule. When the owner asks in a session to process a recitation:
1. Bootstrap (section 0). Get the file from the Drive link/ID the owner gives (`python3 src/drive.py download <id> inbox/<id>.<ext>`)
   or from the 📥 folder.
2. Pick the background: the agreed list is config `video.backgrounds` (owner-approved, never use another). Read the last
   `videos/*` row (by `created`) and use the NEXT key in the list after its `background` (round robin; first video → first key).
   `python3 src/pipeline.py process inbox/<file> --name "<file title>" --background <key>` — identifies the surah/ayahs from the audio,
   syncs every ayah (Uthmani text + ayah number + التفسير الميسر) with the recitation, renders, and uploads as PRIVATE for preview.
3. Send the owner the two private links + the thumbnail, the identified surah/ayahs and ALL warnings from job.json — especially
   «يختلف نص التفسير الميسر بين المصدرين» (show both texts and ask which to keep) and «آيات تحتاج نظرة… لدقة التوقيت».
   Write the `videos/<job_id>` row including `background`.
4. Only after the owner explicitly says to publish (e.g. «انشر»): `python3 src/pipeline.py publish jobs/<job_id>`
   (or `--only long` / `--only short` if they choose). Exit 7 means YouTube kept it private — report it (likely the API audit lock).
