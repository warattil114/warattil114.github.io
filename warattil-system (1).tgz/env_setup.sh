#!/bin/bash
# نص إعداد بيئة «وَرَتِّل»: يثبّت النظام وأدواته قبل بدء كل جلسة (يدوية أو مجدولة).
set -e
mkdir -p /home/user/quran-channel
curl -fsSL https://raw.githubusercontent.com/warattil114/warattil114.github.io/main/warattil-system.tgz | tar xz -C /home/user/quran-channel
cd /home/user/quran-channel && bash setup.sh
