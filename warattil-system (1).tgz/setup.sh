#!/usr/bin/env bash
# تجهيز بيئة التشغيل: يتحقق من الأدوات ويُنشئ حلقات الخلفية إن لم تكن موجودة (مرة واحدة لكل حاوية).
set -euo pipefail
cd "$(dirname "$0")"
command -v ffmpeg >/dev/null || { echo "ffmpeg missing"; exit 1; }
python3 -c "import numpy" 2>/dev/null || pip install -q numpy
mkdir -p jobs logs reports inbox models
python3 -c "import sherpa_onnx" 2>/dev/null || pip install -q sherpa-onnx
if [ ! -d models/sherpa-onnx-whisper-small ]; then
  curl -sSL https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-small.tar.bz2 | tar xj -C models
  rm -f models/sherpa-onnx-whisper-small/small-encoder.onnx models/sherpa-onnx-whisper-small/small-decoder.onnx
fi
python3 -c "import sys;sys.path.insert(0,'src');import video;video.bg_loop();video.bg_loop(True)"
echo "setup ok"
