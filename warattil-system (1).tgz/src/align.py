#!/usr/bin/env python3
"""مزامنة الآيات مع صوت القارئ: تقطيع التلاوة عند الوقفات، تفريغ كل مقطع، ثم محاذاة المقاطع مع كلمات الآيات
(برمجة ديناميكية رتيبة) لاستخراج زمن بداية كل آية ونهايتها، مع درجة ثقة لكل آية.
النص المعروض يُؤخذ من المصحف دائمًا؛ التفريغ يُستخدم للتوقيت فقط.
الاستخدام: python3 src/align.py <صوت> <سورة> <من> <إلى>"""
import json, subprocess, sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio, identify  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
MODEL = ROOT / "models" / "sherpa-onnx-whisper-small"


def segments(path, min_len=0.9, max_len=27.0):
    """مقاطع الكلام بين الوقفات. الحدود عند منتصف الوقفة."""
    env = audio.envelope(path)
    dur = len(env) * 0.05
    pauses, *_ = audio.pauses(env, min_d=0.35)
    bounds = [0.0] + [round((s + e) / 2, 2) for s, e in pauses if e and 0 < s and e < dur] + [round(dur, 2)]
    segs = [[a, b] for a, b in zip(bounds, bounds[1:]) if b - a > 0.05]
    merged = []
    for s in segs:  # دمج المقاطع القصيرة جدًا مع السابقة
        if merged and (s[1] - s[0] < min_len or merged[-1][1] - merged[-1][0] < min_len) and s[1] - merged[-1][0] <= max_len:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    out = []
    for a, b in merged:  # تقسيم ما يتجاوز حد النموذج
        while b - a > max_len:
            out.append([a, a + max_len]); a += max_len
        out.append([a, b])
    return out, dur


def transcribe_segments(path, segs):
    import sherpa_onnx
    rec = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=str(MODEL / "small-encoder.int8.onnx"), decoder=str(MODEL / "small-decoder.int8.onnx"),
        tokens=str(MODEL / "small-tokens.txt"), language="ar", task="transcribe", num_threads=4)
    x = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
                                     capture_output=True, check=True).stdout, dtype=np.float32)
    out = []
    for a, b in segs:
        st = rec.create_stream()
        st.accept_waveform(16000, x[max(0, int((a - 0.15) * 16000)):int((b + 0.15) * 16000)])
        rec.decode_stream(st)
        out.append({"start": a, "end": b, "text": st.result.text.strip(), "tokens": identify.norm(st.result.text)})
    return out


def _sim(a, b):
    """تشابه كلمتين (يتسامح مع أخطاء التفريغ البسيطة)."""
    if a == b:
        return 1.0
    if len(a) >= 3 and len(b) >= 3:
        from difflib import SequenceMatcher
        r = SequenceMatcher(None, a, b).ratio()
        return r if r >= 0.75 else 0.0
    return 0.0


def _lcs(t, w):
    """أطول تطابق مرتّب بين كلمات المقطع وكلمات المصحف؛ يُرجع الدرجة ومواضع الكلمات المطابقة في w."""
    n, m = len(t), len(w)
    D = np.zeros((n + 1, m + 1))
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            s = _sim(t[i - 1], w[j - 1])
            D[i, j] = max(D[i - 1, j], D[i, j - 1], D[i - 1, j - 1] + s if s else 0)
    i, j, hit = n, m, []
    while i and j:
        s = _sim(t[i - 1], w[j - 1])
        if s and D[i, j] == D[i - 1, j - 1] + s:
            hit.append(j - 1); i -= 1; j -= 1
        elif D[i - 1, j] >= D[i, j - 1]:
            i -= 1
        else:
            j -= 1
    return D[n, m], sorted(hit)


def align(segs, words):
    """برمجة ديناميكية: كل مقطع يأخذ مدى متصلًا من كلمات المصحف (أو لا شيء: استعاذة/بسملة/ضجيج)، بترتيب التلاوة."""
    W = [w for _, w in words]
    N, M = len(W), len(segs)
    NEG = -1e9
    best = np.full((M + 1, N + 1), NEG)
    back = {}
    best[0, 0] = 0.0
    for k in range(M):
        t = segs[k]["tokens"]
        L = len(t)
        for i in range(N + 1):
            if best[k, i] <= NEG / 2:
                continue
            # خيار: المقطع خارج النطاق (استعاذة، بسملة، تكرار، ضجيج)
            sc = best[k, i] - 0.6 * L
            if sc > best[k + 1, i]:
                best[k + 1, i] = sc; back[(k + 1, i)] = (i, None)
            if not L:
                continue
            lo, hi = max(1, int(L * 0.5)), int(L * 1.8) + 3
            for span in range(lo, hi + 1):
                j = i + span
                if j > N:
                    break
                s, hit = _lcs(t, W[i:j])
                sc = best[k, i] + 2 * s - L - span
                if sc > best[k + 1, j]:
                    best[k + 1, j] = sc; back[(k + 1, j)] = (i, [i + h for h in hit])
    # نسمح بكلمات غير مقروءة في النهاية بعقوبة (قد ينتهي التسجيل قبل آخر آية)
    end_j = max(range(N + 1), key=lambda j: best[M, j] - (N - j) * 1.0)
    spans, j = [None] * M, end_j
    for k in range(M, 0, -1):
        i, hit = back[(k, j)]
        spans[k - 1] = (i, j, hit) if hit is not None else None
        j = i
    return spans, end_j


def ayah_times(segs, spans, words, end_word):
    """زمن بداية كل آية: بداية المقطع الذي تقع فيه أول كلماتها (مع توزيع نسبي داخل المقطع إن بدأت في وسطه)."""
    first_word = {}
    for idx, (a, _) in enumerate(words):
        first_word.setdefault(a, idx)
    matched = set()
    for sp in spans:
        if sp:
            matched.update(sp[2])
    res = []
    ayahs = sorted(first_word)
    for n, a in enumerate(ayahs):
        w0 = first_word[a]
        w1 = first_word[ayahs[n + 1]] if n + 1 < len(ayahs) else len(words)
        if w0 >= end_word:
            res.append({"ayah": a, "start": None, "conf": 0.0})
            continue
        start = None
        for k, sp in enumerate(spans):
            if sp and sp[0] <= w0 < sp[1]:
                seg = segs[k]
                frac = (w0 - sp[0]) / max(1, sp[1] - sp[0])
                start = round(seg["start"] + frac * (seg["end"] - seg["start"]), 2)
                break
        conf = sum(1 for i in range(w0, w1) if i in matched) / max(1, w1 - w0)
        res.append({"ayah": a, "start": start, "conf": round(conf, 2)})
    # آيات بلا مقطع (نادر): تُقدَّر بين جارتيها
    for n, r in enumerate(res):
        if r["start"] is None:
            prev = next((x["start"] for x in reversed(res[:n]) if x["start"] is not None), 0.0)
            nxt = next((x["start"] for x in res[n + 1:] if x["start"] is not None), None)
            r["start"] = round((prev + nxt) / 2, 2) if nxt else prev
            r["estimated"] = True
    last_end = max((segs[k]["end"] for k, sp in enumerate(spans) if sp), default=segs[-1]["end"])
    for n, r in enumerate(res):
        r["end"] = res[n + 1]["start"] if n + 1 < len(res) else round(last_end, 2)
    return res


def run(path, surah, a_from, a_to):
    quran = json.loads((ROOT / "assets" / "quran.json").read_text(encoding="utf-8"))
    words = [(v["id"], w) for v in quran[surah - 1]["verses"] if a_from <= v["id"] <= a_to for w in identify.norm(v["text"])]
    segs, dur = segments(path)
    segs = transcribe_segments(path, segs)
    spans, end_word = align(segs, words)
    times = ayah_times(segs, spans, words, end_word)
    low = [t["ayah"] for t in times if t["conf"] < 0.5 or t.get("estimated")]
    return {"surah": surah, "from": a_from, "to": a_to, "duration": round(dur, 2), "ayahs": times,
            "low_confidence": low, "words_covered": f"{end_word}/{len(words)}",
            "segments": [{k: s[k] for k in ("start", "end", "text")} | {"span": spans[i][:2] if spans[i] else None} for i, s in enumerate(segs)]}


if __name__ == "__main__":
    p, s, a, b = sys.argv[1], *map(int, sys.argv[2:5])
    print(json.dumps(run(p, s, a, b), ensure_ascii=False, indent=1))
