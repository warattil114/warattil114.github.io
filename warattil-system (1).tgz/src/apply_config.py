#!/usr/bin/env python3
"""يدمج الإعدادات المعتمدة من المالك (المخزنة في قاعدة بيانات لوحة التحكم) في config.json. يقبل فقط مفاتيح معروفة."""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ALLOWED = {"channel": {"reciter_name", "name_ar", "name_en"},
           "publish": {"mode", "long_slot", "short_slot", "timezone", "category_id"},
           "audio": {"denoise", "target_lufs"}, "video": {"make_shorts", "short_max_seconds", "backgrounds", "verses"}}

over = json.loads(sys.argv[1])
cfg = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
applied = []
for sec, keys in ALLOWED.items():
    for k, v in (over.get(sec) or {}).items():
        if k in keys:
            cfg[sec][k] = v
            applied.append(f"{sec}.{k}")
assert cfg["publish"]["mode"] in ("private", "schedule", "public")
(ROOT / "config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
print("applied:", ", ".join(applied) or "nothing")
