"""فحص الصوت وتحسينه دون المساس بالتلاوة: لا تغيير في الطبقة أو السرعة أو المخارج.
التحسين يقتصر على: إزالة الهمهمة المنخفضة، تخفيف ضوضاء خفيف عند الحاجة فقط، وتطبيع مستوى الصوت."""
import json, re, subprocess
from pathlib import Path
import numpy as np


def _ff(args, timeout=3600):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", *args], capture_output=True, text=True, timeout=timeout)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-2000:])
    return r.stderr


def probe(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
                       capture_output=True, text=True, check=True)
    d = json.loads(r.stdout)
    a = next((s for s in d["streams"] if s["codec_type"] == "audio"), None)
    if not a:
        raise ValueError("الملف لا يحتوي على مسار صوتي")
    return {"duration": float(d["format"].get("duration") or a.get("duration") or 0),
            "codec": a.get("codec_name"), "sample_rate": int(a.get("sample_rate", 0)),
            "channels": a.get("channels"), "bit_rate": int(d["format"].get("bit_rate") or 0)}


def loudness(path, start=None, dur=None):
    pre = (["-ss", str(start)] if start else []) + (["-t", str(dur)] if dur else [])
    err = _ff([*pre, "-i", str(path), "-af", "loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"])
    return json.loads(err[err.rindex("{"):err.rindex("}") + 1])


def silences(path, noise_db=-38, min_d=0.45):
    err = _ff(["-i", str(path), "-af", f"silencedetect=noise={noise_db}dB:d={min_d}", "-f", "null", "-"])
    out, st = [], None
    for line in err.splitlines():
        m = re.search(r"silence_start: ([\d.]+)", line)
        if m:
            st = float(m.group(1))
        m = re.search(r"silence_end: ([\d.]+)", line)
        if m and st is not None:
            out.append((st, float(m.group(1))))
            st = None
    if st is not None:
        out.append((st, None))
    return out


def stats(path):
    err = _ff(["-i", str(path), "-af", "astats=measure_overall=Peak_level+RMS_level+Noise_floor+Number_of_samples:measure_perchannel=none,volumedetect",
               "-f", "null", "-"])
    g = lambda k: (re.findall(rf"{k}: (-?[\d.]+|-inf)", err) or [None])[-1]
    num = lambda v: None if v in (None, "-inf") else float(v)
    clipped = int(g("histogram_0db") or 0)
    return {"peak_db": num(g("Peak level dB")), "rms_db": num(g("RMS level dB")),
            "noise_floor_db": num(g("Noise floor dB")), "max_volume_db": num(g("max_volume")),
            "samples_at_0db": clipped}


def envelope(path, af=None, hop=0.05):
    """غلاف الطاقة بنوافذ 50ms (dBFS) لتقدير الضوضاء والوقفات بدقة تتكيف مع كل تسجيل."""
    cmd = ["ffmpeg", "-v", "error", "-i", str(path)] + (["-af", af] if af else []) + ["-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
    x = np.frombuffer(subprocess.run(cmd, capture_output=True, check=True, timeout=3600).stdout, dtype=np.float32)
    n = int(16000 * hop)
    x = x[: len(x) // n * n].reshape(-1, n)
    return 10 * np.log10(np.mean(x.astype(np.float64) ** 2, axis=1) + 1e-12)


def pauses(env, hop=0.05, min_d=0.45):
    """الوقفات: مقاطع أدنى من (الضوضاء + 40% من المسافة بين الضوضاء والصوت)."""
    noise, voice = np.percentile(env, 8), np.percentile(env, 70)
    thr = noise + 0.4 * (voice - noise)
    quiet = env < thr
    out, i = [], 0
    while i < len(quiet):
        if quiet[i]:
            j = i
            while j < len(quiet) and quiet[j]:
                j += 1
            if (j - i) * hop >= min_d:
                out.append((round(i * hop, 2), round(j * hop, 2) if j < len(quiet) else None))
            i = j
        else:
            i += 1
    return out, float(noise), float(voice), float(thr)


def analyze(path):
    info = probe(path)
    st = stats(path)
    ln = loudness(path)
    env = envelope(path)
    sil, noise, voice, thr = pauses(env)
    st["noise_floor_db"] = round(noise, 1)
    st["voice_level_db"] = round(voice, 1)
    st["snr_db"] = round(voice - noise, 1)
    issues, warnings = [], []
    dur = info["duration"]
    if dur < 10:
        issues.append(f"المقطع قصير جدًا ({dur:.1f} ث)")
    if float(ln["input_i"]) < -45:
        issues.append("مستوى الصوت منخفض جدًا أو الملف صامت")
    if st["samples_at_0db"] and st["samples_at_0db"] > 50:
        warnings.append(f"تشبّع/قصّ في الصوت ({st['samples_at_0db']} عينة عند 0dB) — يُفضّل خفض مستوى الميكروفون في التسجيلات القادمة")
    if st["snr_db"] < 20:
        warnings.append(f"ضوضاء خلفية ملحوظة (الفرق بين الصوت والضوضاء {st['snr_db']:.0f} dB) — يُفضّل التسجيل في مكان أهدأ")
    if info["sample_rate"] and info["sample_rate"] < 22050:
        warnings.append(f"معدل عينات منخفض ({info['sample_rate']} Hz)")
    speech = dur - sum(((e or dur) - s) for s, e in sil)
    return {**info, **st, "lufs": float(ln["input_i"]), "lra": float(ln["input_lra"]), "true_peak": float(ln["input_tp"]),
            "silences": sil, "speech_ratio": round(speech / dur, 3) if dur else 0,
            "issues": issues, "warnings": warnings, "loudnorm_measure": ln}


def trim_points(an, keep=0.8):
    """قص الصمت الطويل في بداية الملف ونهايته فقط (لا يُمس أي صمت داخل التلاوة)."""
    dur, sil = an["duration"], an["silences"]
    start, end = 0.0, dur
    if sil and sil[0][0] <= 0.05 and sil[0][1] and sil[0][1] - keep > 1.0:
        start = sil[0][1] - keep
    if sil and (sil[-1][1] is None or sil[-1][1] >= dur - 0.05) and dur - sil[-1][0] > keep + 1.0:
        end = sil[-1][0] + keep
    return round(start, 3), round(end, 3)


def enhance(src, dst, an, target_lufs=-16.0, denoise=True):
    """سلسلة التحسين. تُرجع وصف الخطوات المطبّقة."""
    start, end = trim_points(an)
    chain, applied = ["highpass=f=60"], ["مرشح تمرير عالٍ 60Hz لإزالة الهمهمة المنخفضة"]
    if an.get("channels") == 1:
        chain.append("pan=stereo|c0=c0|c1=c0")
    snr, nf = an.get("snr_db", 99), an.get("noise_floor_db")
    if denoise and snr < 35 and nf is not None and nf > -70:
        nr = 6 if snr >= 25 else 9 if snr >= 15 else 12  # خفيف عمدًا لتجنب أي تشويه في الصوت
        chain.append(f"afftdn=nr={nr}:nf={max(-80, min(-20, nf)):.0f}")
        applied.append(f"تخفيف ضوضاء خفيف ({nr}dB) لأن الفرق بين الصوت والضوضاء {snr:.0f}dB")
    # قياس الجهارة بعد السلسلة ثم كسب ثابت (لا ضغط ولا محدِّد) حتى لا تتغير ديناميكية التلاوة
    pre = ["-ss", str(start), "-to", str(end)]
    err = _ff([*pre, "-i", str(src), "-af", ",".join(chain) + ",loudnorm=print_format=json", "-f", "null", "-"])
    m = json.loads(err[err.rindex("{"):err.rindex("}") + 1])
    gain = target_lufs - float(m["input_i"])
    gain = min(gain, -1.5 - float(m["input_tp"]))  # لا تجاوز لذروة -1.5dBTP
    chain.append(f"volume={gain:.2f}dB")
    applied.append(f"ضبط مستوى الصوت بكسب ثابت {gain:+.1f}dB (الجهارة النهائية ≈ {float(m['input_i']) + gain:.1f} LUFS دون ضغط ديناميكي)")
    chain.append("aresample=48000")
    if start or end < an["duration"]:
        applied.append(f"قص الصمت الطرفي فقط: البداية {start:.1f}ث، النهاية {an['duration'] - end:.1f}ث")
    _ff(["-y", "-ss", str(start), "-to", str(end), "-i", str(src), "-af", ",".join(chain), "-c:a", "aac", "-b:a", "256k", "-ar", "48000", str(dst)])
    return {"applied": applied, "trim": [start, end]}


def short_segment(an_enh, max_len=58.0, min_len=20.0):
    """اختيار مقطع قصير من البداية ينتهي عند وقفة طبيعية (نهاية آية غالبًا) — لا قطع في منتصف الكلام."""
    dur = an_enh["duration"]
    if dur <= max_len:
        return (0.0, dur)
    cands = [(s + min(e, s + 1.2)) / 2 for s, e in an_enh["silences"] if e and min_len <= s <= max_len and e - s >= 0.45]
    if not cands:
        return None
    return (0.0, round(max(cands), 2))
