"""الخلفيات المعتمدة للقناة (تصميم أصلي بلا حقوق نشر). كل خلفية تُرسم صورةً كبيرة ثم تُحوَّل إلى حلقة فيديو هادئة
(تقريب وإبعاد بطيء جدًا ذهابًا وإيابًا ⇒ حلقة سلسة). التدوير بين الخلفيات يتم من قائمة config.video.backgrounds."""
import math, random, subprocess
from pathlib import Path

import brand

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "assets" / "backgrounds"
C = brand.C


def _stars(w, h, n, seed, max_y=1.0, color="#fff"):
    rnd = random.Random(seed)
    dots = []
    for _ in range(n):
        x, y, r = rnd.uniform(0, w), rnd.uniform(0, h * max_y), rnd.choice([0.8, 1.0, 1.2, 1.6, 2.2])
        o = rnd.uniform(0.25, 0.9)
        dots.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r}" fill="{color}" fill-opacity="{o:.2f}"/>')
    return "".join(dots)


def _skyline(w, h, base, color, seed=3):
    """صورة ظلية لقباب ومآذن (رسم هندسي أصلي)."""
    rnd = random.Random(seed)
    parts, x = [], 0
    while x < w:
        kind = rnd.choice(["dome", "dome", "minaret", "block"])
        if kind == "dome":
            r = rnd.randint(70, 150); bh = rnd.randint(60, 140)
            parts.append(f'<rect x="{x}" y="{base - bh}" width="{2 * r}" height="{bh + 5}"/>'
                         f'<path d="M{x} {base - bh} A{r} {r * 1.1:.0f} 0 0 1 {x + 2 * r} {base - bh} Z"/>'
                         f'<rect x="{x + r - 3}" y="{base - bh - r * 1.1 - 40:.0f}" width="6" height="40"/>'
                         f'<circle cx="{x + r}" cy="{base - bh - r * 1.1 - 48:.0f}" r="7"/>')
            x += 2 * r + rnd.randint(10, 60)
        elif kind == "minaret":
            mh = rnd.randint(260, 420); mw = rnd.randint(22, 34)
            parts.append(f'<rect x="{x}" y="{base - mh}" width="{mw}" height="{mh}"/>'
                         f'<rect x="{x - 8}" y="{base - mh * 0.72:.0f}" width="{mw + 16}" height="10"/>'
                         f'<path d="M{x} {base - mh} L{x + mw / 2} {base - mh - 60} L{x + mw} {base - mh} Z"/>')
            x += mw + rnd.randint(40, 120)
        else:
            bw = rnd.randint(120, 260); bh = rnd.randint(50, 110)
            parts.append(f'<rect x="{x}" y="{base - bh}" width="{bw}" height="{bh}"/>')
            x += bw
    return f'<g fill="{color}">{"".join(parts)}<rect x="0" y="{base}" width="{w}" height="{h - base}"/></g>'


def _dunes(w, h, layers):
    out = []
    for i, (y, amp, col, seed) in enumerate(layers):
        rnd = random.Random(seed)
        pts, x = [f"M0 {h}", f"L0 {y}"], 0
        while x <= w:
            x2 = x + rnd.randint(300, 600)
            out_y = y + rnd.randint(-amp, amp)
            pts.append(f"Q{(x + x2) / 2:.0f} {out_y - amp} {x2} {out_y:.0f}")
            x = x2
        pts.append(f"L{w} {h} Z")
        out.append(f'<path d="{" ".join(pts)}" fill="{col}"/>')
    return "".join(out)


def svg_page(w, h, inner, defs=""):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" style="position:absolute;inset:0">'
            f'<defs>{defs}</defs>{inner}</svg>')


def designs(w, h):
    """أربع خلفيات مقترحة. الأبعاد تُضخَّم 12% لإتاحة حركة التقريب."""
    V = h > w
    d = {}
    # ١) ليل الزخرفة: الهوية الحالية
    d["night_pattern"] = ("ليل الزخرفة", '<div class="bg"></div><div class="pat"></div><div class="vig"></div>'
                          f'<div style="position:absolute;left:50%;top:50%;width:{min(w, h) * 0.9:.0f}px;height:{min(w, h) * 0.9:.0f}px;'
                          f'transform:translate(-50%,-50%);opacity:.55">{brand.rosette_svg(int(min(w, h) * 0.9), op=.16)}</div>')
    # ٢) فجر وقباب
    base = int(h * (0.80 if V else 0.78))
    d["dawn_domes"] = ("فجر المآذن", svg_page(w, h,
        f'<rect width="{w}" height="{h}" fill="url(#g)"/>{_stars(w, h, 160, 7, 0.55)}'
        f'<circle cx="{w * 0.78:.0f}" cy="{h * 0.2:.0f}" r="{min(w, h) * 0.05:.0f}" fill="#f6e7c1" fill-opacity=".85"/>'
        f'<circle cx="{w * 0.78 + min(w, h) * 0.022:.0f}" cy="{h * 0.2 - min(w, h) * 0.012:.0f}" r="{min(w, h) * 0.046:.0f}" fill="#22324f"/>'
        + _skyline(w, h, base, "#0b1220", 11),
        '<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0a1430"/>'
        '<stop offset=".55" stop-color="#22324f"/><stop offset=".82" stop-color="#7a5a4a"/><stop offset="1" stop-color="#c79a62"/></linearGradient>')
        + '<div class="vig" style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 40%,rgba(0,0,0,.05) 30%,rgba(0,0,0,.55) 100%)"></div>')
    # ٣) كثبان تحت النجوم
    d["desert_stars"] = ("كثبان ونجوم", svg_page(w, h,
        f'<rect width="{w}" height="{h}" fill="url(#g)"/>{_stars(w, h, 380, 21, 0.7)}'
        + _dunes(w, h, [(h * 0.66, 40, "#2a2238", 5), (h * 0.74, 34, "#1d1a2a", 9), (h * 0.84, 28, "#120f1b", 13)]),
        '<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#060914"/>'
        '<stop offset=".6" stop-color="#18203a"/><stop offset="1" stop-color="#3b2f45"/></linearGradient>')
        + '<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 45%,transparent 40%,rgba(0,0,0,.5) 100%)"></div>')
    # ٤) المحراب: قوس زخرفي بألوان الرمل والعنابي
    aw, ah = (w * 0.86, h * 0.80) if V else (w * 0.62, h * 0.9)
    ax, ay = (w - aw) / 2, h - ah
    r = aw / 2
    arch = (f'M{ax:.0f} {h} L{ax:.0f} {ay + r:.0f} Q{ax:.0f} {ay:.0f} {w / 2:.0f} {ay - r * 0.25:.0f} '
            f'Q{ax + aw:.0f} {ay:.0f} {ax + aw:.0f} {ay + r:.0f} L{ax + aw:.0f} {h} Z')
    d["mihrab"] = ("المحراب", svg_page(w, h,
        f'<rect width="{w}" height="{h}" fill="#2a1416"/>'
        f'<rect width="{w}" height="{h}" fill="url(#p)" opacity=".5"/>'
        f'<path d="{arch}" fill="url(#g)" stroke="{C["gold"]}" stroke-opacity=".55" stroke-width="6"/>'
        f'<path d="{arch}" fill="none" stroke="{C["gold"]}" stroke-opacity=".25" stroke-width="2" transform="translate({w * 0.02:.0f} {h * 0.02:.0f}) scale({1 - 0.04 * w / w:.3f})"/>',
        f'<linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d2422"/><stop offset="1" stop-color="#170b0c"/></linearGradient>'
        f'<pattern id="p" width="120" height="120" patternUnits="userSpaceOnUse"><g fill="none" stroke="{C["gold"]}" stroke-opacity=".12" stroke-width="1.2">'
        f'<rect x="30" y="30" width="60" height="60"/><rect x="30" y="30" width="60" height="60" transform="rotate(45 60 60)"/></g></pattern>')
        + '<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 50% 55%,transparent 35%,rgba(0,0,0,.55) 100%)"></div>')
    return d


def render_stills(vertical=False):
    w, h = (1080, 1920) if vertical else (1920, 1080)
    W, H = int(w * 1.12), int(h * 1.12)
    OUT.mkdir(parents=True, exist_ok=True)
    res = {}
    for key, (name, body) in designs(W, H).items():
        png = OUT / f"{key}_{'v' if vertical else 'h'}.png"
        if not png.exists():
            brand.render(brand.page(W, H, body), png, W, H)
        res[key] = (name, png)
    return res


def loop(key, vertical=False, fps=24, seconds=30):
    """حلقة فيديو: تقريب بطيء ثم إبعاد (ذهاب وإياب) ⇒ بداية الحلقة ونهايتها متطابقتان."""
    w, h = (1080, 1920) if vertical else (1920, 1080)
    out = OUT / f"{key}_{'v' if vertical else 'h'}.mp4"
    if out.exists():
        return out
    png = render_stills(vertical)[key][1]
    if key == "night_pattern":  # الهوية الحالية: الزخرفة الدوّارة
        import video
        return video.bg_loop(vertical, fps)
    n = int(fps * seconds)
    W, H = (w + w % 2), (h + h % 2)
    # تقريب ناعم (تحجيم لكل إطار بدقة دون البكسل ثم قص المنتصف): 1.0 → 1.06 → 1.0 خلال الحلقة
    z = f"(1.0+0.03*(1-cos(2*PI*n/{n})))"
    vf = f"scale=w='trunc({W}*{z}/2)*2':h='trunc({H}*{z}/2)*2':eval=frame:flags=bicubic,crop={w}:{h},format=yuv420p"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-framerate", str(fps), "-i", str(png), "-vf", vf, "-frames:v", str(n),
                    "-c:v", "libx264", "-preset", "slow", "-crf", "16", "-r", str(fps), str(out.with_suffix(".tmp.mp4"))], check=True, timeout=3600)
    out.with_suffix(".tmp.mp4").rename(out)  # لا يُخزَّن ملف ناقص إذا تعطلت العملية
    return out
