"""الهوية البصرية: قوالب HTML تُرسم إلى PNG عبر Chromium (يدعم تشكيل الحروف العربية بشكل صحيح)."""
import os, subprocess, tempfile, shutil, glob
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FONTS = ROOT / "assets" / "fonts"

# لوحة الألوان: ليل هادئ + ذهبي خافت + عاجي
C = {"bg1": "#071a22", "bg2": "#0c2f36", "bg3": "#123f43", "gold": "#cfa957",
     "gold2": "#e9cf8f", "ivory": "#f4ecd8", "muted": "#9fb7b3"}

# شعار الآية من المصدر العثماني (المزمل: ٤) — منقول حرفيًا من ملف المصحف المعتمد في المشروع
MOTTO = "وَرَتِّلِ ٱلۡقُرۡءَانَ تَرۡتِيلًا"
MOTTO_REF = "المزمل: ٤"

AR_DIGITS = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")


def ar_num(n):
    return str(n).translate(AR_DIGITS)


def _chrome():
    for p in [os.environ.get("CHROME_BIN", ""), *glob.glob("/opt/pw-browsers/chromium_headless_shell-*/chrome-linux/headless_shell"),
              *glob.glob("/opt/pw-browsers/chromium-*/chrome-linux/chrome"),
              shutil.which("chromium") or "", shutil.which("google-chrome") or ""]:
        if p and os.path.exists(p):
            return p
    raise RuntimeError("Chromium غير متوفر")


def font_css():
    f = FONTS.as_uri()
    return f"""
@font-face{{font-family:AmiriQuran;src:url({f}/AmiriQuran.woff2)}}
@font-face{{font-family:Amiri;font-weight:400;src:url({f}/amiri-arabic-400-normal.woff2)}}
@font-face{{font-family:Amiri;font-weight:700;src:url({f}/amiri-arabic-700-normal.woff2)}}
@font-face{{font-family:Naskh;font-weight:400;src:url({f}/noto-naskh-arabic-arabic-400-normal.woff2)}}
@font-face{{font-family:Naskh;font-weight:700;src:url({f}/noto-naskh-arabic-arabic-700-normal.woff2)}}
@font-face{{font-family:Kufi;font-weight:400;src:url({f}/reem-kufi-arabic-400-normal.woff2)}}
@font-face{{font-family:Kufi;font-weight:700;src:url({f}/reem-kufi-arabic-700-normal.woff2)}}
"""


def _star_tile(size=120, stroke=C["gold"], op=0.10):
    """بلاطة نجمة ثمانية (خاتم) لنقش هندسي إسلامي خافت."""
    s, h = size, size / 2
    r = s * 0.36
    sq = f'<rect x="{h-r/1.414:.1f}" y="{h-r/1.414:.1f}" width="{r*1.414:.1f}" height="{r*1.414:.1f}"'
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{s}" height="{s}" viewBox="0 0 {s} {s}">'
           f'<g fill="none" stroke="{stroke}" stroke-opacity="{op}" stroke-width="1.2">'
           f'{sq}/>{sq} transform="rotate(45 {h} {h})"/>'
           f'<circle cx="{h}" cy="{h}" r="{r*0.42:.1f}"/>'
           f'<path d="M0 0L{s*0.14:.1f} {s*0.14:.1f}M{s} 0L{s*0.86:.1f} {s*0.14:.1f}M0 {s}L{s*0.14:.1f} {s*0.86:.1f}M{s} {s}L{s*0.86:.1f} {s*0.86:.1f}"/>'
           f'</g></svg>')
    return "data:image/svg+xml;utf8," + svg.replace("#", "%23").replace('"', "'")


def rosette_svg(size=1000, op=0.22, stroke=C["gold"]):
    """زخرفة نجمية دائرية (16 رأسًا) تُدار ببطء خلف العنوان."""
    h = size / 2
    parts = []
    for k, r in enumerate([0.46, 0.34, 0.22]):
        rr = size * r
        for i in range(4):
            parts.append(f'<rect x="{h-rr/1.414:.1f}" y="{h-rr/1.414:.1f}" width="{rr*1.414:.1f}" height="{rr*1.414:.1f}" '
                         f'transform="rotate({i*22.5 + k*11.25} {h} {h})"/>')
    for r in [0.485, 0.40, 0.155, 0.08]:
        parts.append(f'<circle cx="{h}" cy="{h}" r="{size*r:.1f}"/>')
    for i in range(32):
        parts.append(f'<circle cx="{h}" cy="{h - size*0.442:.1f}" r="{size*0.006:.1f}" transform="rotate({i*11.25} {h} {h})" fill="{stroke}" fill-opacity="{op*1.4}"/>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" viewBox="0 0 {size} {size}">'
            f'<g fill="none" stroke="{stroke}" stroke-opacity="{op}" stroke-width="{size/700:.2f}">{"".join(parts)}</g></svg>')


def page(w, h, body, extra_css="", transparent=False):
    bg = "transparent" if transparent else C["bg1"]
    return f"""<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
{font_css()}
*{{margin:0;padding:0;box-sizing:border-box}}
html,body{{width:{w}px;height:{h}px;overflow:hidden;background:{bg}}}
body{{font-family:Naskh,Amiri,serif;color:{C['ivory']};position:relative}}
.bg{{position:absolute;inset:0;background:
  radial-gradient(ellipse at 50% 42%,{C['bg3']} 0%,{C['bg2']} 38%,{C['bg1']} 78%);}}
.pat{{position:absolute;inset:0;background-image:url("{_star_tile()}");background-size:{max(90, w//16)}px;
  -webkit-mask-image:radial-gradient(ellipse at 50% 50%,rgba(0,0,0,.25) 0%,#000 75%);}}
.vig{{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 50%,transparent 55%,rgba(0,0,0,.45) 100%)}}
.c{{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center}}
.gold{{color:{C['gold2']}}}
.orn{{display:flex;align-items:center;gap:18px;color:{C['gold']}}}
.orn i{{display:block;height:1.5px;width:160px;background:linear-gradient(90deg,transparent,{C['gold']},transparent)}}
.orn b{{display:block;width:12px;height:12px;border:1.5px solid {C['gold']};transform:rotate(45deg)}}
{extra_css}
</style></head><body>{body}</body></html>"""


def render(html, out_png, w, h, transparent=False):
    out_png = Path(out_png)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "p.html"
        src.write_text(html, encoding="utf-8")
        cmd = [_chrome(), "--no-sandbox", "--disable-gpu", "--hide-scrollbars",
               "--allow-file-access-from-files", "--force-device-scale-factor=1",
               f"--window-size={w},{h}", "--virtual-time-budget=4000", f"--user-data-dir={td}/u",
               f"--screenshot={out_png}", src.as_uri()]
        if "headless_shell" not in cmd[0]:
            cmd.insert(1, "--headless=new")
        if transparent:
            cmd.insert(2, "--default-background-color=00000000")
        subprocess.run(cmd, check=True, capture_output=True, timeout=120)
    if not out_png.exists():
        raise RuntimeError(f"فشل رسم {out_png}")
    return out_png


def orn():
    return '<div class="orn"><i></i><b></b><i></i></div>'


# ---------------- أصول القناة ----------------

def emblem(size, text=True):
    """شعار القناة: نجمة ثمانية ذهبية وبداخلها «رتّل»."""
    r = rosette_svg(size, op=0.55, stroke=C["gold"])
    t = (f'<div class="c"><div style="font-family:Amiri;font-weight:700;font-size:{size*0.25:.0f}px;'
         f'color:{C["gold2"]};margin-top:-{size*0.03:.0f}px;text-shadow:0 0 {size*0.03:.0f}px rgba(0,0,0,.6)">وَرَتِّل</div></div>') if text else ""
    return f'<div style="position:absolute;inset:0">{r}</div>{t}'


def channel_assets(out_dir, channel_name_ar="وَرَتِّل"):
    out = Path(out_dir)
    # صورة القناة 800×800 (تُقص دائريًا في يوتيوب)
    render(page(800, 800, f'<div class="bg"></div><div class="pat"></div><div class="vig"></div>'
                          f'<div style="position:absolute;inset:70px">{emblem(660)}</div>'),
           out / "profile_800.png", 800, 800)
    # الغلاف 2560×1440 — المنطقة الآمنة للعرض على كل الأجهزة 1546×423 في المنتصف
    banner = f"""<div class="bg"></div><div class="pat"></div><div class="vig"></div>
<div style="position:absolute;left:50%;top:50%;width:1300px;height:1300px;transform:translate(-50%,-50%);opacity:.55">{rosette_svg(1300, op=.16)}</div>
<div class="c" style="gap:14px">
  <div style="font-family:Amiri;font-weight:700;font-size:190px;line-height:1.05" class="gold">{channel_name_ar}</div>
  {orn()}
  <div style="font-family:AmiriQuran;font-size:66px;color:{C['ivory']};line-height:1.6">﴿{MOTTO}﴾</div>
  <div style="font-size:34px;color:{C['muted']};letter-spacing:.5px">تلاوات قرآنية · مقاطع جديدة باستمرار</div>
</div>"""
    render(page(2560, 1440, banner), out / "banner_2560x1440.png", 2560, 1440)
    # العلامة المائية 150×150 بخلفية شفافة
    render(page(300, 300, f'<div style="position:absolute;inset:6px;border-radius:50%;background:rgba(7,26,34,.55)"></div>'
                          f'<div style="position:absolute;inset:14px">{emblem(272)}</div>', transparent=True),
           out / "watermark_300.png", 300, 300, transparent=True)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(out / "watermark_300.png"), "-vf", "scale=150:150:flags=lanczos",
                    str(out / "watermark_150.png")], check=True)
    # زخرفة الحركة (شفافة) تُستخدم في كل الفيديوهات
    render(page(1000, 1000, rosette_svg(1000, op=.20), transparent=True), out / "rosette_1000.png", 1000, 1000, transparent=True)
    return out


# ---------------- قوالب الفيديو والصورة المصغرة ----------------

def _title_block(info, scale=1.0, reciter=True):
    s = lambda px: f"{px*scale:.0f}px"
    if info.get("surah_name"):
        title = f'<div style="font-family:Amiri;font-weight:700;font-size:{s(56)};color:{C["muted"]}">سُورَةُ</div>' \
                f'<div class="gold" style="font-family:Amiri;font-weight:700;font-size:{s(170)};line-height:1.15;text-shadow:0 4px 30px rgba(0,0,0,.5)">{info["surah_name"]}</div>'
    else:
        title = f'<div class="gold" style="font-family:Amiri;font-weight:700;font-size:{s(120)};line-height:1.2">تلاوة قرآنية</div>'
    sub = ""
    if info.get("ayah_from"):
        a, b = info["ayah_from"], info.get("ayah_to") or info["ayah_from"]
        sub = f'الآيات {ar_num(a)} – {ar_num(b)}' if b != a else f'الآية {ar_num(a)}'
        if info.get("full_surah"):
            sub = "كاملة"
    elif info.get("surah_name") and info.get("partial"):
        sub = "مقطع من السورة"
    sub_html = f'<div style="font-size:{s(44)};color:{C["ivory"]};opacity:.9;margin-top:{s(6)}">{sub}</div>' if sub else ""
    rec = info.get("reciter") if reciter else ""
    rec_html = f'<div style="font-size:{s(34)};color:{C["muted"]};margin-top:{s(18)}">بصوت: {rec}</div>' if rec else ""
    return f'{title}{orn() if sub or rec else ""}{sub_html}{rec_html}'


def video_layers(info, out_dir, vertical=False):
    """يرسم طبقة النص الشفافة الخاصة بكل فيديو (الخلفية المتحركة مشتركة: video.bg_loop)."""
    out = Path(out_dir)
    w, h = (1080, 1920) if vertical else (1920, 1080)
    tag = "v" if vertical else "h"
    brand = (f'<div style="position:absolute;{"top:110px;left:0;right:0;text-align:center" if vertical else "bottom:44px;left:56px"};'
             f'font-family:Amiri;font-weight:700;font-size:{40 if vertical else 34}px;color:{C["gold"]};opacity:.85">وَرَتِّل</div>')
    body = f'<div class="c" style="gap:4px">{_title_block(info, 1.0 if not vertical else 1.3)}</div>{brand}'
    render(page(w, h, body, transparent=True), out / f"text_{tag}.png", w, h, transparent=True)
    return out / f"text_{tag}.png"


def thumbnail(info, out_png):
    w, h = 1280, 720
    a, b = info.get("ayah_from"), info.get("ayah_to")
    badge = ""
    if info.get("full_surah"):
        badge = "كاملة"
    elif a:
        badge = f"الآيات {ar_num(a)}–{ar_num(b or a)}"
    badge_html = (f'<div style="display:inline-block;margin-top:18px;padding:8px 30px;border:2px solid {C["gold"]};border-radius:40px;'
                  f'font-size:42px;font-weight:700;color:{C["ivory"]};background:rgba(7,26,34,.55)">{badge}</div>') if badge else ""
    name = info.get("surah_name")
    big = (f'<div style="font-family:Amiri;font-weight:700;font-size:64px;color:{C["muted"]};line-height:1">سورة</div>'
           f'<div class="gold" style="font-family:Amiri;font-weight:700;font-size:{230 if len(name) <= 6 else 170}px;line-height:1.1;'
           f'text-shadow:0 6px 40px rgba(0,0,0,.6),0 0 60px rgba(207,169,87,.25)">{name}</div>') if name else \
          f'<div class="gold" style="font-family:Amiri;font-weight:700;font-size:150px;line-height:1.15">تلاوة قرآنية</div>'
    rec = info.get("reciter")
    rec_html = f'<div style="font-size:40px;color:{C["ivory"]};margin-top:16px;font-weight:700">{rec}</div>' if rec else ""
    body = f"""<div class="bg"></div><div class="pat"></div>
<div style="position:absolute;left:-170px;top:50%;width:820px;height:820px;transform:translateY(-50%);opacity:.9">{rosette_svg(820, op=.32)}</div>
<div class="vig"></div>
<div style="position:absolute;right:70px;top:0;bottom:0;width:760px;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center">
{big}{badge_html}{rec_html}</div>
<div style="position:absolute;left:44px;bottom:30px;font-family:Amiri;font-weight:700;font-size:40px;color:{C['gold']}">وَرَتِّل</div>"""
    return render(page(w, h, body), out_png, w, h)
