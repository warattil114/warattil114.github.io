#!/usr/bin/env python3
"""تجهيز القناة عبر الواجهة الرسمية (مرة واحدة بعد التفويض): الوصف، الكلمات المفتاحية، البلد واللغة، الغلاف، العلامة المائية، قوائم التشغيل.
ما لا تتيحه الواجهة البرمجية (يُنفَّذ يدويًا في YouTube Studio): اسم القناة، المعرّف @، صورة القناة، توثيق الجوال.
الاستخدام: python3 src/channel_setup.py [--check]"""
import argparse, json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import youtube  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
BRAND = ROOT / "assets" / "brand"


def description(c):
    ch = c["channel"]
    rec = ch.get("reciter_name")
    who = f" بصوت القارئ {rec}" if rec else ""
    return (f"{ch['name_ar']} — قناة لتلاوات القرآن الكريم{who}.\n\n"
            "تُنشر هنا تلاوات من سور القرآن الكريم بتسجيلات أصلية، دون موسيقى أو مؤثرات صوتية، "
            "مع ذكر اسم السورة وأرقام الآيات في كل مقطع، وقوائم تشغيل مرتبة حسب السور.\n\n"
            "﴿وَرَتِّلِ ٱلۡقُرۡءَانَ تَرۡتِيلًا﴾ [المزمل: ٤]\n\n"
            "🔔 اشترك وفعّل التنبيهات ليصلك جديد التلاوات.\n"
            "#القرآن_الكريم #تلاوة #ترتيل")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="فحص الربط والصلاحيات فقط دون أي تعديل")
    a = ap.parse_args()
    c = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
    yt = youtube.YouTube()
    ch = yt.my_channel()
    cid = ch["id"]
    res = {"channel_id": cid, "title": ch["snippet"]["title"], "custom_url": ch["snippet"].get("customUrl"),
           "subscribers": ch["statistics"].get("subscriberCount"), "videos": ch["statistics"].get("videoCount"),
           "long_uploads_status": ch.get("status", {}).get("longUploadsStatus"),
           "url": f"https://www.youtube.com/channel/{cid}", "granted_scopes": getattr(yt, "scopes", "").split()}
    if a.check:
        try:
            yt.report("2020-01-01", "2020-01-02", "views")
            res["analytics"] = "ok"
        except Exception as e:
            res["analytics"] = f"غير متاح: {e}"
        print(json.dumps(res, ensure_ascii=False, indent=1))
        return
    done, failed = [], []
    steps = [
        ("الوصف والكلمات المفتاحية والبلد واللغة", lambda: yt.update_branding(cid, description(c), c["channel"]["keywords"],
                                                                             c["channel"]["country"], c["channel"]["default_language"])),
        ("غلاف القناة", lambda: yt.set_banner(cid, BRAND / "banner_2560x1440.png")),
        ("العلامة المائية للفيديوهات", lambda: yt.set_watermark(cid, BRAND / "watermark_150.png")),
    ]
    name = c["channel"]["name_ar"]
    for t, d in [(f"جميع التلاوات | {name}", f"كل التلاوات المنشورة على قناة {name}."), (f"مقاطع قصيرة | {name}", "مقاطع قصيرة من التلاوات.")]:
        steps.append((f"قائمة التشغيل «{t}»", lambda t=t, d=d: yt.ensure_playlist(t, d)))
    for label, fn in steps:
        try:
            fn()
            done.append(label)
        except Exception as e:
            failed.append(f"{label}: {e}")
    res.update(done=done, failed=failed, manual=[
        "رفع صورة القناة assets/brand/profile_800.png من YouTube Studio ← التخصيص ← العلامة التجارية (لا تتيحها الواجهة البرمجية)",
        "توثيق القناة برقم الجوال youtube.com/verify لتفعيل الصور المصغرة المخصصة والفيديوهات الأطول من 15 دقيقة"
        if res["long_uploads_status"] != "allowed" else None])
    res["manual"] = [m for m in res["manual"] if m]
    print(json.dumps(res, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
