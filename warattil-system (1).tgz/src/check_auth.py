#!/usr/bin/env python3
"""يطبع فقط: هل متغيرات الربط موجودة، وهل تقبلها Google (دون أي قيمة سرية)."""
import json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import youtube  # noqa: E402

out = {"configured": youtube.configured()}
if out["configured"]:
    try:
        ch = youtube.YouTube().my_channel()
        out.update(ok=True, channel=ch["snippet"]["title"], channel_id=ch["id"])
    except Exception as e:
        out.update(ok=False, error=str(e)[:200])
print(json.dumps(out, ensure_ascii=False))
