#!/usr/bin/env python3
"""وصول مباشر إلى Google Drive بنفس تفويض OAuth (نطاق drive) — بديل عن موصل Drive في الجلسات المجدولة.
  python3 src/drive.py list <folder_id>                 → JSON: الملفات الصوتية في المجلد (الأقدم أولًا)
  python3 src/drive.py download <file_id> <dest>       → تنزيل الملف
  python3 src/drive.py move <file_id> <new_parent_id>   → نقل الملف (لا حذف أبدًا)
  python3 src/drive.py upload_text <parent_id> <title> <file.md>  → حفظ تقرير كمستند Google"""
import json, sys, urllib.parse, urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import youtube  # noqa: E402

API = "https://www.googleapis.com/drive/v3/files"
AUDIO_EXT = (".m4a", ".mp3", ".wav", ".ogg", ".opus", ".aac", ".flac", ".mp4", ".3gp", ".amr", ".webm")


def main():
    yt = youtube.YouTube()
    cmd = sys.argv[1]
    if cmd == "list":
        q = f"'{sys.argv[2]}' in parents and trashed = false"
        r = yt._req("GET", API, {"q": q, "orderBy": "createdTime", "pageSize": 100,
                                 "fields": "files(id,name,mimeType,size,description,createdTime)", "supportsAllDrives": "true",
                                 "includeItemsFromAllDrives": "true"})
        files = [f for f in r.get("files", []) if f["mimeType"].startswith(("audio/", "video/")) or f["name"].lower().endswith(AUDIO_EXT)]
        print(json.dumps(files, ensure_ascii=False))
    elif cmd == "download":
        req = urllib.request.Request(f"{API}/{sys.argv[2]}?alt=media&supportsAllDrives=true", headers={"Authorization": f"Bearer {yt.token()}"})
        with urllib.request.urlopen(req, timeout=600) as r, open(sys.argv[3], "wb") as f:
            while chunk := r.read(1 << 20):
                f.write(chunk)
        print(sys.argv[3])
    elif cmd == "move":
        cur = yt._req("GET", f"{API}/{sys.argv[2]}", {"fields": "parents", "supportsAllDrives": "true"})
        yt._req("PATCH", f"{API}/{sys.argv[2]}", {"addParents": sys.argv[3], "removeParents": ",".join(cur.get("parents", [])),
                                                  "supportsAllDrives": "true"}, body={})
        print("moved")
    elif cmd == "upload_text":
        parent, title, path = sys.argv[2:5]
        boundary = "rep7731"
        meta = json.dumps({"name": title, "parents": [parent], "mimeType": "application/vnd.google-apps.document"})
        body = (f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{meta}\r\n--{boundary}\r\n"
                f"Content-Type: text/markdown; charset=UTF-8\r\n\r\n").encode() + Path(path).read_bytes() + f"\r\n--{boundary}--".encode()
        r = yt._req("POST", "https://www.googleapis.com/upload/drive/v3/files", {"uploadType": "multipart", "fields": "id,webViewLink",
                                                                                  "supportsAllDrives": "true"},
                    data=body, ctype=f"multipart/related; boundary={boundary}")
        print(json.dumps(r))


if __name__ == "__main__":
    main()
