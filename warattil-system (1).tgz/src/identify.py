#!/usr/bin/env python3
"""التعرّف على السورة والآيات من التلاوة: تفريغ صوتي (Whisper عبر sherpa-onnx، يعمل محليًا) ثم مطابقة النص المفرَّغ
مع نص المصحف كاملًا. النص المعروض/المعتمد يُؤخذ دائمًا من المصحف، لا من التفريغ.
الاستخدام: python3 src/identify.py <ملف_صوتي> [--model-dir DIR]
يطبع JSON: السورة، أول وآخر آية، نسبة التغطية والثقة، وتفصيل كل مقطع."""
import argparse, json, re, subprocess, sys, unicodedata
from difflib import SequenceMatcher
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
QURAN = ROOT / "assets" / "quran.json"


def norm(t):
    t = "".join(c for c in unicodedata.normalize("NFKD", t) if not unicodedata.combining(c))
    t = re.sub(r"[ؐ-ًؚ-ٰٟۖ-ۭـ]", "", t)
    for a, b in [("ٱ", "ا"), ("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ى", "ي"), ("ة", "ه"), ("ؤ", "و"), ("ئ", "ي"), ("ء", "")]:
        t = t.replace(a, b)
    return re.sub(r"[^ء-ي ]", " ", t).split()


def load_quran():
    data = json.loads(QURAN.read_text(encoding="utf-8"))
    words = []  # (surah, ayah, word)
    for s in data:
        for v in s["verses"]:
            for w in norm(v["text"]):
                words.append((s["id"], v["id"], w))
    return data, words


def transcribe(path, model_dir, max_chunk=28.0):
    import sherpa_onnx
    md = Path(model_dir)
    pre = "small" if (md / "small-tokens.txt").exists() else next(md.glob("*-tokens.txt")).name.split("-tokens")[0]
    rec = sherpa_onnx.OfflineRecognizer.from_whisper(
        encoder=str(md / f"{pre}-encoder.int8.onnx"), decoder=str(md / f"{pre}-decoder.int8.onnx"),
        tokens=str(md / f"{pre}-tokens.txt"), language="ar", task="transcribe", num_threads=4)
    x = np.frombuffer(subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "16000", "-f", "f32le", "-"],
                                     capture_output=True, check=True).stdout, dtype=np.float32)
    dur = len(x) / 16000
    env = audio.envelope(path)
    pauses, *_ = audio.pauses(env)
    cuts = [0.0]
    mids = [(s + e) / 2 for s, e in pauses if e]
    while dur - cuts[-1] > max_chunk:
        cand = [m for m in mids if cuts[-1] + 3 < m <= cuts[-1] + max_chunk]
        cuts.append(max(cand) if cand else cuts[-1] + max_chunk)
    cuts.append(dur)
    out = []
    for a, b in zip(cuts, cuts[1:]):
        st = rec.create_stream()
        st.accept_waveform(16000, x[int(a * 16000):int(b * 16000)])
        rec.decode_stream(st)
        out.append({"start": round(a, 2), "end": round(b, 2), "text": st.result.text.strip()})
    return out


def match(chunks, words):
    """يبحث عن أفضل موضع متصل في المصحف لكل مقطع، ثم يتحقق من التسلسل."""
    qw = [w for _, _, w in words]
    # فهرس ثلاثيات الكلمات لتسريع البحث عن المرشحين
    idx = {}
    for i in range(len(qw) - 2):
        idx.setdefault((qw[i], qw[i + 1], qw[i + 2]), []).append(i)
    bigram = {}
    for i in range(len(qw) - 1):
        bigram.setdefault((qw[i], qw[i + 1]), []).append(i)
    res = []
    for c in chunks:
        tw = norm(c["text"])
        if len(tw) < 3:
            res.append({**c, "match": None})
            continue
        votes = {}
        for j in range(len(tw) - 1):
            for i in bigram.get((tw[j], tw[j + 1]), []):
                votes[i - j] = votes.get(i - j, 0) + 1
            if j < len(tw) - 2:
                for i in idx.get((tw[j], tw[j + 1], tw[j + 2]), []):
                    votes[i - j] = votes.get(i - j, 0) + 2
        best = None
        for off, _ in sorted(votes.items(), key=lambda kv: -kv[1])[:25]:
            lo, hi = max(0, off - 5), min(len(qw), off + len(tw) + 5)
            sm = SequenceMatcher(None, tw, qw[lo:hi], autojunk=False)
            blocks = [b for b in sm.get_matching_blocks() if b.size]
            if not blocks:
                continue
            score = sum(b.size for b in blocks) / len(tw)
            s0, s1 = lo + blocks[0].b, lo + blocks[-1].b + blocks[-1].size - 1
            if not best or score > best["score"]:
                best = {"score": round(score, 3), "from": words[s0][:2], "to": words[s1][:2], "pos": [s0, s1]}
        res.append({**c, "match": best})
    return res


def refine(res, words):
    """المرور الثاني: حصر المطابقة في السورة الغالبة وبترتيب التلاوة (يحسم اللوازم المكررة مثل «فبأي آلاء ربكما تكذبان»)."""
    from collections import Counter
    cnt = Counter()
    for r in res:
        m = r["match"]
        if m and m["score"] >= 0.5:
            cnt[m["from"][0]] += m["score"] * len(norm(r["text"]))
    if not cnt:
        return res
    sur = cnt.most_common(1)[0][0]
    lo_s = next(i for i, w in enumerate(words) if w[0] == sur)
    hi_s = max(i for i, w in enumerate(words) if w[0] == sur) + 1
    qw = [w for _, _, w in words]
    prev = None  # أول مقطع يُبحث له في السورة كاملة
    out = []
    for r in res:
        tw = norm(r["text"])
        if len(tw) < 1:
            out.append({**r, "match": None})
            continue
        best = None
        span = len(tw) * 3 + 40  # التلاوة متصلة: المقطع التالي يبدأ قريبًا من نهاية السابق
        rng = range(lo_s, hi_s) if prev is None else range(max(lo_s, prev - 3), min(hi_s, prev + span))
        for off in rng:
            lo, hi = off, min(hi_s, off + len(tw) + 4)
            sm = SequenceMatcher(None, tw, qw[lo:hi], autojunk=False)
            blocks = [b for b in sm.get_matching_blocks() if b.size]
            if not blocks:
                continue
            score = sum(b.size for b in blocks) / len(tw)
            s0, s1 = lo + blocks[0].b, lo + blocks[-1].b + blocks[-1].size - 1
            rank = score - (0 if prev is None else 0.004 * max(0, s0 - prev))  # الأقرب يُفضَّل
            if not best or rank > best["_rank"]:
                best = {"score": round(score, 3), "from": words[s0][:2], "to": words[s1][:2], "pos": [s0, s1], "_rank": rank}
        if best:
            best.pop("_rank")
        if best and best["score"] >= 0.4:
            prev = best["pos"][1] + 1
            out.append({**r, "match": best})
        else:
            out.append({**r, "match": None})
    return out


def summarize(res, quran):
    good = [r for r in res if r["match"] and r["match"]["score"] >= 0.4]
    if not good:
        return {"identified": False, "reason": "لم يطابق التفريغ أي موضع في المصحف بثقة كافية"}
    surahs = {r["match"]["from"][0] for r in good} | {r["match"]["to"][0] for r in good}
    seq_ok = all(a["match"]["pos"][0] <= b["match"]["pos"][0] for a, b in zip(good, good[1:]))
    s = good[0]["match"]["from"][0]
    first, last = good[0]["match"]["from"], good[-1]["match"]["to"]
    words_total = sum(len(norm(r["text"])) for r in res)
    words_matched = sum(len(norm(r["text"])) * r["match"]["score"] for r in good)
    conf = words_matched / max(1, words_total)
    total_ayahs = quran[s - 1]["total_verses"]
    return {"identified": len(surahs) == 1 and seq_ok and conf >= 0.6,
            "surah": s, "surah_name": quran[s - 1]["name"], "ayah_from": first[1], "ayah_to": last[1], "surah_ayahs": total_ayahs,
            "same_surah": len(surahs) == 1, "in_order": seq_ok, "confidence": round(conf, 3),
            "chunks_matched": f"{len(good)}/{len(res)}", "surahs_seen": sorted(surahs)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("audio")
    ap.add_argument("--model-dir", default=str(ROOT / "models" / "sherpa-onnx-whisper-small"))
    a = ap.parse_args()
    quran, words = load_quran()
    chunks = transcribe(a.audio, a.model_dir)
    res = refine(match(chunks, words), words)
    print(json.dumps({"summary": summarize(res, quran), "chunks": res}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
