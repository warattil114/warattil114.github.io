"""بيانات الفيديو: تحديد السورة والآيات من اسم الملف (كما كتبها القارئ) والتحقق منها مقابل بيانات المصحف،
ثم توليد العنوان والوصف والوسوم. لا تخمين: إن لم تُذكر السورة بوضوح يتوقف الفيديو بحالة needs_info."""
import json, re, unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SURAHS = json.loads((ROOT / "assets" / "surahs.json").read_text(encoding="utf-8"))
TO_LATIN = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def norm(t):
    t = "".join(ch for ch in unicodedata.normalize("NFKD", t) if not unicodedata.combining(ch))
    t = t.replace("ـ", "")
    for a, b in [("أ", "ا"), ("إ", "ا"), ("آ", "ا"), ("ٱ", "ا"), ("ى", "ي"), ("ة", "ه"), ("ؤ", "و"), ("ئ", "ي")]:
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t).strip()


_INDEX = {}
for s in SURAHS:
    n = norm(s["name"])
    for k in {n, n.replace(" ", ""), n[2:] if n.startswith("ال") else "ال" + n}:
        _INDEX.setdefault(k, s)
    _INDEX.setdefault(re.sub(r"[^a-z]", "", s["tr"].lower()), s)
# أسماء بديلة شائعة
for alt, num in [("الاسراء", 17), ("بني اسرائيل", 17), ("غافر", 40), ("المومن", 40), ("فصلت", 41), ("حم السجده", 41), ("محمد", 47),
                 ("القتال", 47), ("التوبه", 9), ("براءه", 9), ("الانسان", 76), ("الدهر", 76), ("تبارك", 67), ("الملك", 67),
                 ("عم", 78), ("النبا", 78), ("الاخلاص", 112), ("ياسين", 36), ("يس", 36), ("طه", 20), ("ص", 38), ("ق", 50)]:
    _INDEX[norm(alt)] = SURAHS[num - 1]


def surah_by_number(n):
    return SURAHS[n - 1] if 1 <= n <= 114 else None


def parse_name(text):
    """يستخرج السورة والآيات من نص مثل: «يس 1-12» أو «سورة البقرة ٢٥٥» أو «036_001-012» أو «الكهف كاملة».
    يُرجع dict أو None إن لم تتضح السورة."""
    raw = Path(text).stem if "." in text[-6:] else text
    t = norm(raw.translate(TO_LATIN)).replace("_", " ").replace("–", "-").replace("—", "-")
    t = re.sub(r"\b(whatsapp|audio|voice|rec|recording|تسجيل|مقطع|تلاوه)\b", " ", t, flags=re.I)
    t = re.sub(r"\d{4}[-.]\d{2}[-.]\d{2}.*$", " ", t)  # تواريخ أسماء ملفات الواتساب
    t = re.sub(r"\s+", " ", t).strip()
    full = bool(re.search(r"كامله|full", t))
    s = None
    if not re.search(r"[\u0621-\u064A]{2,}|[a-z]{3,}", t):  # صيغة رقمية فقط: 036_001-012 أو 36 1-12
        nums = [int(x) for x in re.findall(r"\d{1,3}", t)]
        if not nums:
            return None
        a = nums[1] if len(nums) > 1 else None
        return _validate(surah_by_number(nums[0]), a, nums[2] if len(nums) > 2 else a, full)
    words = re.sub(r"سوره\s*", "", t)
    words = re.sub(r"[^ء-يa-z ]", " ", words)
    words = re.sub(r"\s+", " ", words).strip()
    toks = words.split()
    for size in (3, 2, 1):  # أطول تطابق أولًا (مثل «ال عمران»)
        for i in range(len(toks) - size + 1):
            cand = " ".join(toks[i:i + size])
            if cand in _INDEX or cand.replace(" ", "") in _INDEX:
                s = _INDEX.get(cand) or _INDEX.get(cand.replace(" ", ""))
                break
        if s:
            break
    if not s:
        return None
    nums = [int(x) for x in re.findall(r"\d{1,3}", t)]
    a = nums[0] if nums else None
    b = nums[1] if len(nums) > 1 else a
    return _validate(s, a, b, full)


def _validate(s, a, b, full=False):
    if not s:
        return None
    r = {"surah": s["n"], "surah_name": s["name"], "surah_tr": s["tr"], "surah_type": s["type"], "surah_ayahs": s["ayahs"],
         "ayah_from": None, "ayah_to": None, "full_surah": False, "partial": True, "errors": []}
    if full:
        r.update(ayah_from=1, ayah_to=s["ayahs"], full_surah=True, partial=False)
    elif a:
        if b < a:
            a, b = b, a
        if a < 1 or b > s["ayahs"]:
            r["errors"].append(f"نطاق الآيات {a}-{b} خارج حدود سورة {s['name']} ({s['ayahs']} آية)")
        else:
            r.update(ayah_from=a, ayah_to=b, full_surah=(a == 1 and b == s["ayahs"]), partial=not (a == 1 and b == s["ayahs"]))
    return r


def _range_txt(info):
    if info.get("full_surah"):
        return "كاملة"
    if info.get("ayah_from"):
        a, b = info["ayah_from"], info["ayah_to"]
        return f"الآيات {a}-{b}" if b != a else f"الآية {a}"
    return ""


def build(info, cfg, kind="long", links=None):
    """kind: long | short. يُرجع العنوان والوصف والوسوم واسم الملف."""
    ch = cfg["channel"]
    brand, reciter = ch["name_ar"], ch.get("reciter_name") or ""
    links = links or {}
    name = info["surah_name"]
    rng = _range_txt(info)
    by = f"تلاوة {reciter}" if reciter else f"تلاوات {brand}"
    if kind == "long":
        if info.get("full_surah"):
            title = f"سورة {name} كاملة | {by}"
        elif rng:
            title = f"سورة {name} | {rng} | {by}"
        else:
            title = f"من سورة {name} | {by}"
    else:
        title = f"من سورة {name} | {by}"
    title = title[:100]
    hashtag = lambda x: "#" + re.sub(r"\s+", "_", x)
    lines = [f"سورة {name}" + (f" — {rng}" if rng else (" — مقطع" if kind == "short" else "")),
             f"بصوت: {reciter}" if reciter else "", "",
             f"📖 السورة: {name} — رقم {info['surah']} في المصحف — {'مكية' if info['surah_type'] == 'meccan' else 'مدنية'} — عدد آياتها {info['surah_ayahs']}"]
    if kind == "short":
        lines.append("هذا المقطع جزء من التلاوة الكاملة المنشورة على القناة.")
    if links.get("full_video"):
        lines.append(f"▶️ التلاوة كاملة: {links['full_video']}")
    if links.get("playlist"):
        lines.append(f"📂 قائمة تلاوات سورة {name}: {links['playlist']}")
    if links.get("channel"):
        lines.append(f"🔔 اشترك في القناة ليصلك جديد التلاوات: {links['channel']}?sub_confirmation=1")
    lines += ["", f"﴿وَرَتِّلِ ٱلۡقُرۡءَانَ تَرۡتِيلًا﴾ [المزمل: ٤]", "",
              "التلاوة بصوت صاحب القناة، والخلفية زخرفة هندسية من تصميم القناة.",
              "", " ".join([hashtag("القرآن_الكريم"), hashtag(f"سورة {name}"), hashtag("تلاوة"), hashtag(brand.replace("َ", "").replace("ِّ", "").replace("ّ", ""))] +
                          ([hashtag(reciter)] if reciter else []) + (["#Shorts"] if kind == "short" else []))]
    desc = "\n".join(l for i, l in enumerate(lines) if l or (i and lines[i - 1])).strip()[:4900]
    tags = ["القرآن الكريم", "قرآن", "تلاوة", "تلاوة قرآن", f"سورة {name}", name, f"تلاوة سورة {name}",
            f"Surah {info['surah_tr']}", "Quran", "Quran recitation", "ترتيل"]
    if reciter:
        tags += [reciter, f"{reciter} تلاوة"]
    if kind == "short":
        tags.append("Shorts")
    # حد يوتيوب 500 حرف للوسوم مجتمعة
    out, total = [], 0
    for t in dict.fromkeys(tags):
        if total + len(t) + 3 > 480:
            break
        out.append(t)
        total += len(t) + 3
    rng_f = f"{info['ayah_from']:03d}-{info['ayah_to']:03d}" if info.get("ayah_from") else "part"
    fname = f"{info['surah']:03d}_{rng_f}_{kind}"
    return {"title": title, "description": desc, "tags": out, "file_stem": fname}
