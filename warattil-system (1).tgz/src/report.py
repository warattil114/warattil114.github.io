#!/usr/bin/env python3
"""التقرير الأسبوعي من YouTube Analytics API والبيانات الرسمية فقط. أي مؤشر غير متاح يُذكر صراحة ولا يُقدَّر.
الاستخدام: python3 src/report.py [--events events.json] [--out reports/]
events.json (اختياري): قائمة الأحداث/الأخطاء خلال الأسبوع من سجل النظام."""
import argparse, datetime as dt, json, sys
from collections import defaultdict
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
import youtube  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
LAG_DAYS = 2  # بيانات Analytics تتأخر عادة 48 ساعة تقريبًا
DAYS_AR = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]
TRAFFIC_AR = {"YT_SEARCH": "بحث يوتيوب", "SUGGESTED_VIDEOS": "الفيديوهات المقترحة", "BROWSE": "الصفحة الرئيسية والتصفح", "SHORTS": "واجهة Shorts", "EXT_URL": "روابط خارجية",
              "PLAYLIST": "قوائم التشغيل", "CHANNEL": "صفحة القناة", "NOTIFICATION": "التنبيهات", "SUBSCRIBER": "خلاصة المشتركين",
              "NO_LINK_OTHER": "مباشر/غير معروف", "YT_OTHER_PAGE": "صفحات يوتيوب أخرى", "RELATED_VIDEO": "فيديوهات ذات صلة",
              "END_SCREEN": "الشاشة النهائية", "HASHTAGS": "الوسوم", "SOUND_PAGE": "صفحة الصوت", "YT_PLAYLIST_PAGE": "صفحة قائمة التشغيل",
              "ANNOTATION": "البطاقات", "CAMPAIGN_CARD": "بطاقات الحملات"}
CORE = "views,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,subscribersGained,subscribersLost,likes,shares,comments"


def safe(fn, notes, label):
    try:
        return fn()
    except Exception as e:
        notes.append(f"{label}: غير متاح ({str(e)[:160]})")
        return None


def pct(a, b):
    if not b:
        return None
    return round((a - b) * 100.0 / b, 1)


def build(events=None):
    yt = youtube.YouTube()
    tz = ZoneInfo("Asia/Riyadh")
    today = dt.datetime.now(tz).date()
    end = today - dt.timedelta(days=LAG_DAYS)
    start = end - dt.timedelta(days=6)
    pend, pstart = start - dt.timedelta(days=1), start - dt.timedelta(days=7)
    f = lambda d: d.isoformat()
    notes = []
    ch = yt.my_channel()
    R = {"generated_at": dt.datetime.now(tz).isoformat(timespec="minutes"), "period": [f(start), f(end)], "previous": [f(pstart), f(pend)],
         "channel": {"id": ch["id"], "title": ch["snippet"]["title"], "subscribers_total": int(ch["statistics"].get("subscriberCount", 0)),
                     "hidden_subscribers": ch["statistics"].get("hiddenSubscriberCount"), "videos_total": int(ch["statistics"].get("videoCount", 0)),
                     "views_total": int(ch["statistics"].get("viewCount", 0))}}

    cur = safe(lambda: yt.report(f(start), f(end), CORE), notes, "إجماليات الأسبوع")
    prev = safe(lambda: yt.report(f(pstart), f(pend), CORE), notes, "إجماليات الأسبوع السابق")
    cur, prev = (cur or [{}])[0] if cur is not None else None, (prev or [{}])[0] if prev is not None else None
    R["totals"], R["totals_prev"] = cur, prev
    if cur and prev:
        R["change_pct"] = {k: pct(cur.get(k, 0) or 0, prev.get(k, 0) or 0) for k in ("views", "estimatedMinutesWatched", "averageViewDuration", "subscribersGained")}

    # الفيديوهات المنشورة هذا الأسبوع (من البيانات الرسمية للقناة)
    uploads = safe(lambda: yt.recent_uploads(50), notes, "قائمة الفيديوهات") or []
    meta = {v["id"]: v for v in uploads}
    R["published_this_week"] = [
        {"id": v["id"], "title": v["snippet"]["title"], "published": v["snippet"]["publishedAt"], "duration": v["contentDetails"]["duration"]}
        for v in uploads if v["status"].get("privacyStatus") == "public"
        and start.isoformat() <= v["snippet"]["publishedAt"][:10] <= today.isoformat()]
    R["scheduled_upcoming"] = [{"id": v["id"], "title": v["snippet"]["title"], "publishAt": v["status"]["publishAt"]}
                               for v in uploads if v["status"].get("publishAt")]
    R["private_unscheduled"] = [{"id": v["id"], "title": v["snippet"]["title"]} for v in uploads
                                if v["status"].get("privacyStatus") == "private" and not v["status"].get("publishAt")]

    vids = safe(lambda: yt.report(f(start), f(end), "views,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,subscribersGained,likes,shares",
                                  "video", sort="-views", max_results=50), notes, "أداء كل فيديو") or []
    for r in vids:
        m = meta.get(r["video"])
        r["title"] = m["snippet"]["title"] if m else r["video"]
    R["per_video"] = vids
    R["top3"] = vids[:3]
    if len(vids) >= 4:
        med = sorted(v["views"] for v in vids)[len(vids) // 2]
        R["weak"] = [v for v in vids if v["views"] < med * 0.5 or (v.get("averageViewPercentage") or 100) < 25][:5]
    else:
        R["weak"] = []
        notes.append("عدد الفيديوهات ذات المشاهدات هذا الأسبوع قليل؛ مقارنة القوي بالضعيف غير ذات دلالة بعد")

    R["by_type"] = safe(lambda: yt.report(f(start), f(end), "views,estimatedMinutesWatched,averageViewDuration", "creatorContentType"),
                        notes, "المقارنة بين الطويل والقصير")
    tr = safe(lambda: yt.report(f(start), f(end), "views,estimatedMinutesWatched", "insightTrafficSourceType", sort="-views"), notes, "مصادر الزيارات")
    R["traffic"] = [{**t, "name": TRAFFIC_AR.get(t["insightTrafficSourceType"], t["insightTrafficSourceType"])} for t in (tr or [])]

    # الاحتفاظ بالجمهور لأفضل فيديو (منحنى نسبة المشاهدة عبر مدة الفيديو)
    if vids:
        top = vids[0]["video"]
        ret = safe(lambda: yt.report("2020-01-01", f(end), "audienceWatchRatio,relativeRetentionPerformance", "elapsedVideoTimeRatio",
                                     filters=f"video=={top}"), notes, "الاحتفاظ بالجمهور")
        if ret:
            pick = {0.1: None, 0.25: None, 0.5: None, 0.75: None, 1.0: None}
            for r in ret:
                for k in pick:
                    if pick[k] is None and r["elapsedVideoTimeRatio"] >= k - 1e-9:
                        pick[k] = round(r["audienceWatchRatio"] * 100, 1)
            R["retention_top"] = {"video": top, "title": vids[0]["title"], "watch_ratio_at": pick}

    # أفضل أيام النشر (لا تتيح الواجهة البرمجية بيانات الساعات؛ نستخدم أيام الأسبوع خلال 90 يومًا)
    days = safe(lambda: yt.report(f(end - dt.timedelta(days=89)), f(end), "views,estimatedMinutesWatched", "day"), notes, "بيانات الأيام")
    if days:
        agg, cnt = defaultdict(float), defaultdict(int)
        for d in days:
            wd = dt.date.fromisoformat(d["day"]).weekday()
            agg[wd] += d["views"]
            cnt[wd] += 1
        total = sum(agg.values())
        if total >= 300:
            R["best_days"] = sorted(({"day": DAYS_AR[k], "avg_views": round(agg[k] / cnt[k], 1)} for k in agg), key=lambda x: -x["avg_views"])[:3]
        else:
            notes.append(f"بيانات المشاهدات خلال 90 يومًا ({int(total)} مشاهدة) غير كافية لاستنتاج أفضل أيام النشر")
    notes.append("أفضل ساعات النشر: لا تتيحها YouTube Analytics API؛ تظهر في YouTube Studio ← الإحصاءات ← الجمهور ← «أوقات تواجد المشاهدين»")
    notes.append("مرات الظهور ونسبة النقر على الصورة المصغرة (CTR): لا تتيحها YouTube Analytics API للقنوات؛ تظهر فقط في YouTube Studio")

    # تقدم أهلية تحقيق الربح (حسابات من البيانات الرسمية، والحالة الرسمية تظهر في Studio فقط)
    y365 = safe(lambda: yt.report(f(end - dt.timedelta(days=364)), f(end), "estimatedMinutesWatched", "creatorContentType"), notes, "ساعات المشاهدة السنوية")
    s90 = safe(lambda: yt.report(f(end - dt.timedelta(days=89)), f(end), "views", "creatorContentType"), notes, "مشاهدات Shorts لـ90 يومًا")
    if y365 is not None and s90 is not None:
        long_h = sum(r["estimatedMinutesWatched"] for r in y365 if r["creatorContentType"] != "SHORTS") / 60
        shorts_v = sum(r["views"] for r in s90 if r["creatorContentType"] == "SHORTS")
        subs = R["channel"]["subscribers_total"]
        R["monetization"] = {"subscribers": subs, "long_watch_hours_365d": round(long_h, 1), "shorts_views_90d": shorts_v,
                             "full_ypp": {"subs": "1000", "hours": "4000", "or_shorts_views": "10,000,000"},
                             "fan_funding_tier": {"subs": "500", "hours": "3000", "or_shorts_views": "3,000,000", "uploads_90d": "3"},
                             "note": "الحساب تقريبي: ساعات المشاهدة تشمل الفيديوهات الطويلة كلها، بينما يحتسب يوتيوب العامة فقط. "
                                     "توفر المستوى الأول (500 مشترك) يختلف حسب البلد، والحالة الرسمية تظهر في Studio ← تحقيق الربح."}
    R["events"] = events or []
    R["notes"] = notes
    return R


def fmt_min(m):
    m = m or 0
    return f"{m / 60:.1f} ساعة" if m >= 60 else f"{m:.0f} دقيقة"


def fmt_sec(s):
    s = int(s or 0)
    return f"{s // 60}:{s % 60:02d}"


def to_md(R):
    L = [f"# التقرير الأسبوعي — {R['channel']['title']}", f"الفترة: {R['period'][0]} إلى {R['period'][1]} (مقارنة بـ {R['previous'][0]} – {R['previous'][1]})",
         f"إجمالي المشتركين الآن: {R['channel']['subscribers_total']} · عدد الفيديوهات: {R['channel']['videos_total']}", ""]
    t, p, ch = R.get("totals"), R.get("totals_prev"), R.get("change_pct", {})
    arrow = lambda v: "" if v is None else f" ({'+' if v >= 0 else ''}{v}%)"
    if t:
        L += ["## الأرقام الرئيسية",
              f"- المشاهدات: {t.get('views', 0)}{arrow(ch.get('views'))}",
              f"- وقت المشاهدة: {fmt_min(t.get('estimatedMinutesWatched'))}{arrow(ch.get('estimatedMinutesWatched'))}",
              f"- متوسط مدة المشاهدة: {fmt_sec(t.get('averageViewDuration'))}{arrow(ch.get('averageViewDuration'))} · متوسط النسبة المشاهدة: {t.get('averageViewPercentage', 0):.0f}%",
              f"- مشتركون جدد: {t.get('subscribersGained', 0)} (فقد {t.get('subscribersLost', 0)}){arrow(ch.get('subscribersGained'))}",
              f"- إعجابات {t.get('likes', 0)} · مشاركات {t.get('shares', 0)} · تعليقات {t.get('comments', 0)}", ""]
    L += [f"## المنشور هذا الأسبوع ({len(R['published_this_week'])})"] + [f"- {v['title']} — https://youtu.be/{v['id']}" for v in R["published_this_week"]] + [""]
    if R["per_video"]:
        L += ["## أداء الفيديوهات", "| الفيديو | المشاهدات | وقت المشاهدة | متوسط المدة | النسبة المشاهدة | مشتركون |", "|---|---|---|---|---|---|"]
        L += [f"| {v['title'][:60]} | {v['views']} | {fmt_min(v['estimatedMinutesWatched'])} | {fmt_sec(v['averageViewDuration'])} | {v['averageViewPercentage']:.0f}% | {v['subscribersGained']} |"
              for v in R["per_video"][:20]] + [""]
    if R.get("by_type"):
        L += ["## الطويل مقابل القصير"] + [f"- {'Shorts' if r['creatorContentType'] == 'SHORTS' else 'فيديو طويل' if r['creatorContentType'] == 'VIDEO_ON_DEMAND' else r['creatorContentType']}: "
                                          f"{r['views']} مشاهدة، {fmt_min(r['estimatedMinutesWatched'])}، متوسط {fmt_sec(r['averageViewDuration'])}" for r in R["by_type"]] + [""]
    if R.get("traffic"):
        tot = sum(x["views"] for x in R["traffic"]) or 1
        L += ["## مصادر الزيارات"] + [f"- {x['name']}: {x['views']} ({x['views'] * 100 // tot}%)" for x in R["traffic"][:8]] + [""]
    if R.get("retention_top"):
        r = R["retention_top"]
        L += [f"## الاحتفاظ بالجمهور — {r['title']}", "نسبة المشاهدين المستمرين عند: " + " · ".join(f"{int(k * 100)}%← {v}%" for k, v in r["watch_ratio_at"].items() if v is not None), ""]
    if R.get("best_days"):
        L += ["## أفضل أيام الأسبوع (90 يومًا)"] + [f"- {d['day']}: متوسط {d['avg_views']} مشاهدة/يوم" for d in R["best_days"]] + [""]
    if R.get("monetization"):
        m = R["monetization"]
        L += ["## تحقيق الربح (تقدّم تقريبي)", f"- المشتركون: {m['subscribers']} / 1000 (أو 500 للمستوى الأول)",
              f"- ساعات مشاهدة الفيديو الطويل (365 يومًا): {m['long_watch_hours_365d']} / 4000 (أو 3000)",
              f"- مشاهدات Shorts (90 يومًا): {m['shorts_views_90d']} / 10,000,000 (أو 3,000,000)", f"- {m['note']}", ""]
    if R.get("scheduled_upcoming"):
        L += ["## المجدول للنشر"] + [f"- {v['publishAt']}: {v['title']}" for v in R["scheduled_upcoming"]] + [""]
    if R.get("private_unscheduled"):
        L += ["## فيديوهات خاصة غير مجدولة"] + [f"- {v['title']} — https://youtu.be/{v['id']}" for v in R["private_unscheduled"]] + [""]
    if R.get("events"):
        L += ["## الأخطاء والمشكلات وكيف عولجت"] + [f"- {e}" if isinstance(e, str) else f"- {e.get('t', '')} {e.get('msg', e)}" for e in R["events"]] + [""]
    L += ["## بيانات غير متاحة / ملاحظات"] + [f"- {n}" for n in R["notes"]]
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--events")
    ap.add_argument("--out", default=str(ROOT / "reports"))
    a = ap.parse_args()
    ev = json.loads(Path(a.events).read_text(encoding="utf-8")) if a.events else None
    R = build(ev)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = f"weekly_{R['period'][1]}"
    (out / f"{stem}.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
    (out / f"{stem}.md").write_text(to_md(R), encoding="utf-8")
    print(out / f"{stem}.md")


if __name__ == "__main__":
    main()
