"""طبقة الآيات المتزامنة: لكل آية لوحة شفافة فيها النص العثماني ورقم الآية والتفسير الميسر واسم السورة والقارئ،
تُعرض في زمنها بدقة مع انتقال ناعم بين الآيات."""
import json, subprocess
from pathlib import Path

from PIL import Image

import brand

ROOT = Path(__file__).resolve().parent.parent
QURAN = json.loads((ROOT / "assets" / "quran_uthmani.json").read_text(encoding="utf-8"))["ayahs"]
TAFSIR = json.loads((ROOT / "assets" / "tafsir_muyassar.json").read_text(encoding="utf-8"))["ayahs"]
_OV = ROOT / "assets" / "tafsir_overrides.json"  # اختيارات المالك حين يختلف المصدران
if _OV.exists():
    for _k, _v in json.loads(_OV.read_text(encoding="utf-8")).items():
        TAFSIR[_k] = {"text": _v["text"], "status": "owner_chosen"}
C = brand.C

FIT_JS = """<script>
function fit(id, min){ const el=document.getElementById(id); if(!el) return;
  let s=parseFloat(getComputedStyle(el).fontSize);
  while((el.scrollHeight>el.clientHeight+2) && s>min){ s-=1; el.style.fontSize=s+'px'; } }
fit('ayah', %d); fit('tafsir', %d);
</script>"""


def tafsir_groups(surah, a_from, a_to):
    """التفسير الميسر يشرح أحيانًا مجموعة آيات بنص واحد: نجمع الآيات المتتالية ذات النص نفسه."""
    groups, cur = [], None
    for a in range(a_from, a_to + 1):
        t = TAFSIR[f"{surah}:{a}"]
        if cur and cur["text"] == t["text"]:
            cur["to"] = a
        else:
            cur = {"from": a, "to": a, "text": t["text"], "status": t["status"], "alt": t.get("alt")}
            groups.append(cur)
    return groups


def _page(w, h, info, ayah_html, tafsir_html, label, vertical):
    rec = info.get("reciter")
    if vertical:
        css = f"""
.top{{position:absolute;top:120px;left:60px;right:60px;text-align:center}}
.sname{{font-family:Amiri;font-weight:700;font-size:64px;color:{C['gold2']}}}
.rec{{font-size:34px;color:{C['muted']};margin-top:4px}}
#ayah{{position:absolute;top:360px;left:70px;right:70px;height:760px;display:flex;align-items:center;justify-content:center;
  text-align:center;font-family:AmiriQuran;font-size:100px;line-height:2.05;color:{C['ivory']};overflow:hidden}}
.tbox{{position:absolute;top:1170px;left:60px;right:60px;max-height:560px;background:rgba(4,16,21,.62);border:1.5px solid rgba(207,169,87,.45);
  border-radius:26px;padding:26px 34px;display:flex;flex-direction:column;gap:10px}}
.tl{{font-size:30px;color:{C['gold']};font-weight:700}}
#tafsir{{max-height:470px;font-size:40px;line-height:1.75;color:{C['ivory']};overflow:hidden}}
.lab{{position:absolute;bottom:120px;left:0;right:0;text-align:center;font-size:32px;color:{C['muted']}}}"""
        min_a, min_t = 44, 26
    else:
        css = f"""
.top{{position:absolute;top:38px;left:64px;right:64px;display:flex;justify-content:space-between;align-items:baseline}}
.sname{{font-family:Amiri;font-weight:700;font-size:54px;color:{C['gold2']}}}
.rec{{font-size:32px;color:{C['muted']}}}
#ayah{{position:absolute;top:150px;left:110px;right:110px;height:500px;display:flex;align-items:center;justify-content:center;
  text-align:center;font-family:AmiriQuran;font-size:84px;line-height:2.0;color:{C['ivory']};overflow:hidden}}
.tbox{{position:absolute;bottom:80px;left:150px;right:150px;max-height:330px;background:rgba(4,16,21,.62);border:1.5px solid rgba(207,169,87,.45);
  border-radius:22px;padding:20px 34px;display:flex;flex-direction:column;gap:6px}}
.tl{{font-size:26px;color:{C['gold']};font-weight:700}}
#tafsir{{max-height:250px;font-size:38px;line-height:1.7;color:{C['ivory']};overflow:hidden}}
.lab{{position:absolute;bottom:26px;left:64px;font-size:28px;color:{C['muted']}}}"""
        min_a, min_t = 40, 24
    rec_html = f'<div class="rec">القارئ: {rec}</div>' if rec else '<div class="rec"></div>'
    body = f"""<div class="top"><div class="sname">سورة {info['surah_name']}</div>{rec_html}</div>
<div id="ayah">{ayah_html}</div>
<div class="tbox"><div class="tl">{tafsir_html[0]}</div><div id="tafsir">{tafsir_html[1]}</div></div>
<div class="lab">{label}</div>""" + FIT_JS % (min_a, min_t)
    return brand.page(w, h, body, extra_css=css, transparent=True)


def build(info, times, out_dir, vertical=False):
    """يرسم لوحة لكل آية. times: [{ayah,start,end}]. يُرجع [(png, start, end)] + ملاحظات التحقق."""
    out = Path(out_dir) / ("verses_v" if vertical else "verses_h")
    out.mkdir(parents=True, exist_ok=True)
    w, h = (1080, 1920) if vertical else (1920, 1080)
    s = info["surah"]
    groups = {a: g for g in tafsir_groups(s, times[0]["ayah"], times[-1]["ayah"]) for a in range(g["from"], g["to"] + 1)}
    notes, panels = [], []
    for t in times:
        a = t["ayah"]
        text = QURAN[f"{s}:{a}"]
        ayah_html = f'{text} <span style="white-space:nowrap">۝{brand.ar_num(a)}</span>'
        g = groups[a]
        lbl = "التفسير الميسر" + (f" — الآيات {brand.ar_num(g['from'])}–{brand.ar_num(g['to'])}" if g["to"] > g["from"] else "")
        if g["status"] == "differs" and a == g["from"]:
            notes.append(f"آية {a}: يختلف نص التفسير الميسر بين المصدرين — المعروض: «{g['text']}» / البديل: «{g['alt']}»")
        png = out / f"a{a:03d}.png"
        brand.render(_page(w, h, info, ayah_html, (lbl, g["text"]), f"الآية {brand.ar_num(a)} من سورة {info['surah_name']}", vertical),
                     png, w, h, transparent=True)
        panels.append((png, t["start"], t["end"]))
    return panels, notes


def title_card(info, out_dir, vertical=False):
    """لوحة البداية (قبل أول آية، مثل الاستعاذة والبسملة)."""
    w, h = (1080, 1920) if vertical else (1920, 1080)
    png = Path(out_dir) / f"title_{'v' if vertical else 'h'}.png"
    return brand.render(brand.page(w, h, f'<div class="c" style="gap:4px">{brand._title_block(info, 1.3 if vertical else 1.0)}</div>',
                                   transparent=True), png, w, h, transparent=True)


def timeline(panels, title_png, total, out_dir, fade=0.3, fps=24):
    """ملف concat للصور مع إطارات انتقال ممزوجة (تلاشٍ متقاطع) بين الآيات."""
    out = Path(out_dir)
    items = []  # (png, duration)
    first = panels[0][1]
    if first > 0.05:
        items.append((title_png, first))
    blank = out / "blank.png"
    if not blank.exists():
        Image.new("RGBA", Image.open(panels[0][0]).size, (0, 0, 0, 0)).save(blank)
    steps = max(1, int(fade * fps))
    prev_img = Image.open(title_png).convert("RGBA") if first > 0.05 else None
    for i, (png, st, en) in enumerate(panels):
        cur = Image.open(png).convert("RGBA")
        if prev_img is not None:
            # التلاشي يبدأ عند بداية الآية ويُقتطع من مدتها
            for k in range(1, steps + 1):
                f = out / f"x_{i:03d}_{k}.png"
                Image.blend(prev_img, cur, k / (steps + 1)).save(f)
                items.append((f, 1 / fps))
            dur = (en - st) - steps / fps
        else:
            dur = en - st
        items.append((png, max(1 / fps, dur)))
        prev_img = cur
    used = sum(d for _, d in items)
    if total - used > 0.01:
        items.append((panels[-1][0], total - used))
    lst = out / "timeline.txt"
    with open(lst, "w") as f:
        for p, d in items:
            f.write(f"file '{p}'\nduration {d:.4f}\n")
        f.write(f"file '{items[-1][0]}'\n")
    return lst


def render(loop_mp4, timeline_txt, audio_path, out, start=0.0, dur=None, fps=24, crf=21):
    if dur is None:
        dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(audio_path)],
                                   capture_output=True, text=True, check=True).stdout) - start
    fo = max(0.0, dur - 1.5)
    fc = (f"[1:v]fps={fps},format=rgba[ov];[0:v][ov]overlay=0:0:format=yuv420:eof_action=repeat,"
          f"fade=t=in:st=0:d=1.0,fade=t=out:st={fo:.2f}:d=1.5,format=yuv420p[v]")
    cmd = ["ffmpeg", "-y", "-v", "error", "-stream_loop", "-1", "-i", str(loop_mp4),
           "-f", "concat", "-safe", "0", "-ss", f"{start:.3f}", "-i", str(timeline_txt),
           "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(audio_path),
           "-filter_complex", fc, "-map", "[v]", "-map", "2:a", "-t", f"{dur:.3f}",
           "-c:v", "libx264", "-preset", "veryfast", "-tune", "stillimage", "-crf", str(crf), "-r", str(fps), "-g", str(fps * 4),
           "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True, timeout=6 * 3600)
    return Path(out)
