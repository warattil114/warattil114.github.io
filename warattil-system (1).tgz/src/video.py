"""إنتاج الفيديو: خلفية ثابتة + زخرفة تدور ببطء شديد + طبقة النص، مع الصوت المحسّن. بلا موسيقى ولا مؤثرات صوتية."""
import json, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ROSETTE = ROOT / "assets" / "brand" / "rosette_1000.png"


LOOP_SEC = 22.5  # الزخرفة متماثلة عند الدوران 22.5° ⇒ حلقة سلسة بلا قفزات (دورة كاملة كل 6 دقائق)


def bg_loop(vertical=False, fps=24):
    """يُنشأ مرة واحدة: خلفية + زخرفة دوّارة كحلقة فيديو قصيرة تُكرَّر في كل الفيديوهات."""
    import brand
    tag = "v" if vertical else "h"
    out = ROOT / "assets" / "brand" / f"loop_{tag}.mp4"
    if out.exists():
        return out
    w, h = (1080, 1920) if vertical else (1920, 1080)
    bg = ROOT / "assets" / "brand" / f"bg_{tag}.png"
    if not bg.exists():
        brand.render(brand.page(w, h, '<div class="bg"></div><div class="pat"></div><div class="vig"></div>'), bg, w, h)
    rs = 1000 if vertical else 900
    fc = (f"[1:v]scale={rs}:{rs},format=rgba,rotate=a=2*PI*t/360:c=none:ow={rs}:oh={rs}[r];"
          f"[0:v][r]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v]")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-framerate", str(fps), "-i", str(bg),
                    "-loop", "1", "-framerate", str(fps), "-i", str(ROSETTE), "-filter_complex", fc, "-map", "[v]",
                    "-frames:v", str(int(LOOP_SEC * fps)), "-c:v", "libx264", "-preset", "slow", "-crf", "14", "-r", str(fps), str(out)],
                   check=True, timeout=3600)
    return out


def render(text, audio, out, vertical=False, start=0.0, dur=None, fps=24, crf=21, preset="veryfast"):
    if dur is None:
        dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(audio)],
                                   capture_output=True, text=True, check=True).stdout) - start
    fo = max(0.0, dur - 1.5)
    fc = (f"[0:v][1:v]overlay=0:0:format=yuv420:eof_action=repeat,fade=t=in:st=0:d=1.2,fade=t=out:st={fo:.2f}:d=1.5,format=yuv420p[v]")
    cmd = ["ffmpeg", "-y", "-v", "error", "-stream_loop", "-1", "-i", str(bg_loop(vertical, fps)),
           "-i", str(text),
           "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(audio),
           "-filter_complex", fc, "-map", "[v]", "-map", "2:a", "-t", f"{dur:.3f}",
           "-c:v", "libx264", "-preset", preset, "-tune", "stillimage", "-crf", str(crf), "-r", str(fps), "-g", str(fps * 4),
           "-c:a", "aac", "-b:a", "256k", "-ar", "48000", "-movflags", "+faststart", str(out)]
    subprocess.run(cmd, check=True, timeout=6 * 3600)
    return Path(out)


def qa(path, expect_dur, vertical=False):
    """مراجعة الجودة: سلامة الملف، وجود المسارين، تطابق المدد، الأبعاد، وفك الترميز بالكامل دون أخطاء."""
    p = json.loads(subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(path)],
                                  capture_output=True, text=True, check=True).stdout)
    v = next((s for s in p["streams"] if s["codec_type"] == "video"), None)
    a = next((s for s in p["streams"] if s["codec_type"] == "audio"), None)
    problems = []
    if not v or not a:
        problems.append("مسار الصورة أو الصوت مفقود")
    else:
        w, h = (1080, 1920) if vertical else (1920, 1080)
        if (v["width"], v["height"]) != (w, h):
            problems.append(f"أبعاد غير متوقعة {v['width']}x{v['height']}")
        vd, ad = float(v.get("duration", 0)), float(a.get("duration", 0))
        if abs(vd - ad) > 0.25:
            problems.append(f"عدم تزامن: مدة الصورة {vd:.2f}ث والصوت {ad:.2f}ث")
        if abs(ad - expect_dur) > 0.5:
            problems.append(f"مدة الصوت {ad:.2f}ث تختلف عن المتوقع {expect_dur:.2f}ث")
        if abs(float(v.get("start_time", 0)) - float(a.get("start_time", 0))) > 0.05:
            problems.append("إزاحة في بداية الصوت عن الصورة")
    err = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-f", "null", "-"], capture_output=True, text=True).stderr.strip()
    if err:
        problems.append("أخطاء فك ترميز: " + err[:300])
    size = Path(path).stat().st_size
    return {"ok": not problems, "problems": problems, "size_mb": round(size / 1e6, 1),
            "duration": float(p["format"]["duration"]), "width": v and v["width"], "height": v and v["height"]}
