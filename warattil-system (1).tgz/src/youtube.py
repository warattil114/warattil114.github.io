"""عميل YouTube Data API v3 و YouTube Analytics API v2 عبر OAuth الرسمي.
بيانات الاعتماد تُقرأ من متغيرات البيئة فقط ولا تُطبع ولا تُكتب في أي ملف أو سجل:
  YT_CLIENT_ID, YT_CLIENT_SECRET, YT_REFRESH_TOKEN"""
import json, os, random, time, urllib.parse, urllib.request, urllib.error
from pathlib import Path

API = "https://www.googleapis.com/youtube/v3"
UPLOAD = "https://www.googleapis.com/upload/youtube/v3"
ANALYTICS = "https://youtubeanalytics.googleapis.com/v2/reports"
RETRY_CODES = {500, 502, 503, 504, 429}


class YTError(Exception):
    def __init__(self, code, body):
        self.code, self.body = code, body
        try:
            e = json.loads(body)["error"]
            self.reason = (e.get("errors") or [{}])[0].get("reason") or e.get("status") or ""
            msg = e.get("message", body)
        except Exception:
            self.reason, msg = "", body
        super().__init__(f"HTTP {code} {self.reason}: {msg[:400]}")


def configured():
    return all(os.environ.get(k) for k in ("YT_CLIENT_ID", "YT_CLIENT_SECRET", "YT_REFRESH_TOKEN"))


class YouTube:
    def __init__(self):
        if not configured():
            raise RuntimeError("ربط يوتيوب غير مكتمل: متغيرات YT_CLIENT_ID / YT_CLIENT_SECRET / YT_REFRESH_TOKEN غير موجودة في البيئة")
        self._tok, self._exp = None, 0

    # ---------- OAuth ----------
    def token(self):
        if self._tok and time.time() < self._exp - 60:
            return self._tok
        data = urllib.parse.urlencode({"client_id": os.environ["YT_CLIENT_ID"], "client_secret": os.environ["YT_CLIENT_SECRET"],
                                       "refresh_token": os.environ["YT_REFRESH_TOKEN"], "grant_type": "refresh_token"}).encode()
        try:
            with urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/token", data=data), timeout=30) as r:
                d = json.load(r)
        except urllib.error.HTTPError as e:
            body = e.read().decode(errors="replace")
            if "invalid_grant" in body:
                raise RuntimeError("انتهت صلاحية تفويض يوتيوب أو أُلغي (invalid_grant) — يلزم إعادة إنشاء رمز التحديث") from None
            raise RuntimeError(f"فشل تجديد التفويض: HTTP {e.code}") from None
        self._tok, self._exp = d["access_token"], time.time() + int(d.get("expires_in", 3600))
        self.scopes = d.get("scope", "")
        return self._tok

    # ---------- HTTP ----------
    def _req(self, method, url, params=None, body=None, data=None, ctype=None, headers=None, tries=6, raw=False):
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params, doseq=True)
        for i in range(tries):
            h = {"Authorization": f"Bearer {self.token()}", **(headers or {})}
            payload = data
            if body is not None:
                payload, h["Content-Type"] = json.dumps(body, ensure_ascii=False).encode(), "application/json; charset=utf-8"
            elif ctype:
                h["Content-Type"] = ctype
            try:
                with urllib.request.urlopen(urllib.request.Request(url, data=payload, method=method, headers=h), timeout=300) as r:
                    content = r.read()
                    if raw:
                        return r
                    return json.loads(content) if content else {}
            except urllib.error.HTTPError as e:
                b = e.read().decode(errors="replace")
                if e.code in RETRY_CODES or (e.code == 403 and "rateLimitExceeded" in b):
                    time.sleep(min(64, 2 ** i) + random.random())
                    continue
                if e.code == 401 and i == 0:
                    self._tok = None
                    continue
                raise YTError(e.code, b) from None
            except (urllib.error.URLError, TimeoutError, ConnectionError):
                time.sleep(min(64, 2 ** i) + random.random())
        raise RuntimeError(f"فشل الطلب بعد {tries} محاولات: {method} {url.split('?')[0]}")

    def get(self, path, **params):
        return self._req("GET", f"{API}/{path}", params)

    # ---------- القناة ----------
    def my_channel(self):
        items = self.get("channels", part="snippet,statistics,brandingSettings,contentDetails,status", mine="true").get("items", [])
        if not items:
            raise RuntimeError("الحساب المفوَّض لا يملك قناة يوتيوب بعد — أنشئ القناة أولًا ثم أعد التفويض")
        return items[0]

    def update_branding(self, channel_id, description, keywords, country="SA", lang="ar", unsubscribed_trailer=None):
        ch = self.my_channel()
        bs = ch.get("brandingSettings", {})
        c = bs.get("channel", {})
        c.update({"description": description, "keywords": keywords, "country": country, "defaultLanguage": lang})
        if unsubscribed_trailer:
            c["unsubscribedTrailer"] = unsubscribed_trailer
        return self._req("PUT", f"{API}/channels", {"part": "brandingSettings"},
                         body={"id": channel_id, "brandingSettings": {"channel": c, "image": bs.get("image", {})}})

    def set_banner(self, channel_id, png_path):
        r = self._req("POST", f"{UPLOAD}/channelBanners/insert", {"uploadType": "media"},
                      data=Path(png_path).read_bytes(), ctype="image/png")
        ch = self.my_channel()
        bs = ch.get("brandingSettings", {})
        return self._req("PUT", f"{API}/channels", {"part": "brandingSettings"},
                         body={"id": channel_id, "brandingSettings": {"channel": bs.get("channel", {}), "image": {"bannerExternalUrl": r["url"]}}})

    def set_watermark(self, channel_id, png_path):
        boundary = "wm" + str(random.randint(10 ** 8, 10 ** 9))
        meta = json.dumps({"timing": {"type": "offsetFromStart", "offsetMs": 0}, "position": {"type": "corner", "cornerPosition": "topRight"}})
        body = (f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n{meta}\r\n--{boundary}\r\nContent-Type: image/png\r\n\r\n").encode() \
            + Path(png_path).read_bytes() + f"\r\n--{boundary}--".encode()
        return self._req("POST", f"{UPLOAD}/watermarks/set", {"channelId": channel_id, "uploadType": "multipart"},
                         data=body, ctype=f"multipart/related; boundary={boundary}")

    # ---------- قوائم التشغيل ----------
    def playlists(self):
        out, tok = [], None
        while True:
            r = self.get("playlists", part="snippet,status", mine="true", maxResults=50, **({"pageToken": tok} if tok else {}))
            out += r.get("items", [])
            tok = r.get("nextPageToken")
            if not tok:
                return out

    def ensure_playlist(self, title, description="", privacy="public", cache=None):
        cache = cache if cache is not None else {p["snippet"]["title"]: p["id"] for p in self.playlists()}
        if title in cache:
            return cache[title]
        r = self._req("POST", f"{API}/playlists", {"part": "snippet,status"},
                      body={"snippet": {"title": title, "description": description, "defaultLanguage": "ar"}, "status": {"privacyStatus": privacy}})
        cache[title] = r["id"]
        return r["id"]

    def add_to_playlist(self, playlist_id, video_id):
        existing = self.get("playlistItems", part="snippet", playlistId=playlist_id, videoId=video_id).get("items", [])
        if existing:
            return existing[0]
        return self._req("POST", f"{API}/playlistItems", {"part": "snippet"},
                         body={"snippet": {"playlistId": playlist_id, "resourceId": {"kind": "youtube#video", "videoId": video_id}}})

    # ---------- الفيديو ----------
    def upload(self, path, snippet, status, log=print, chunk=8 * 1024 * 1024):
        """رفع قابل للاستئناف مع إعادة المحاولة التلقائية عند انقطاع الشبكة أو أخطاء الخادم."""
        size = os.path.getsize(path)
        h = {"X-Upload-Content-Length": str(size), "X-Upload-Content-Type": "video/mp4"}
        r = self._req("POST", f"{UPLOAD}/videos", {"uploadType": "resumable", "part": "snippet,status", "notifySubscribers": "true"},
                      body={"snippet": snippet, "status": status}, headers=h, raw=True)
        session = r.headers["Location"]
        pos, fails = 0, 0
        with open(path, "rb") as f:
            while pos < size:
                f.seek(pos)
                buf = f.read(chunk)
                end = pos + len(buf) - 1
                req = urllib.request.Request(session, data=buf, method="PUT", headers={
                    "Authorization": f"Bearer {self.token()}", "Content-Length": str(len(buf)), "Content-Range": f"bytes {pos}-{end}/{size}"})
                try:
                    with urllib.request.urlopen(req, timeout=600) as resp:
                        return json.load(resp)  # 200/201 ⇒ اكتمل
                except urllib.error.HTTPError as e:
                    if e.code == 308:
                        rng = e.headers.get("Range")
                        pos = int(rng.split("-")[1]) + 1 if rng else 0
                        fails = 0
                        log(f"  رُفع {pos * 100 // size}%")
                        continue
                    if e.code not in RETRY_CODES:
                        raise YTError(e.code, e.read().decode(errors="replace")) from None
                except (urllib.error.URLError, TimeoutError, ConnectionError):
                    pass
                fails += 1
                if fails > 8:
                    raise RuntimeError("تعذر إكمال الرفع بعد عدة محاولات")
                time.sleep(min(64, 2 ** fails) + random.random())
                # الاستعلام عن الموضع الحالي للاستئناف
                q = urllib.request.Request(session, data=b"", method="PUT", headers={
                    "Authorization": f"Bearer {self.token()}", "Content-Range": f"bytes */{size}", "Content-Length": "0"})
                try:
                    with urllib.request.urlopen(q, timeout=60) as resp:
                        return json.load(resp)
                except urllib.error.HTTPError as e:
                    if e.code == 308:
                        rng = e.headers.get("Range")
                        pos = int(rng.split("-")[1]) + 1 if rng else 0
                except Exception:
                    pass
        raise RuntimeError("انتهى الرفع دون استجابة نهائية")

    def set_thumbnail(self, video_id, jpg_path):
        return self._req("POST", f"{UPLOAD}/thumbnails/set", {"videoId": video_id, "uploadType": "media"},
                         data=Path(jpg_path).read_bytes(), ctype="image/jpeg")

    def set_privacy(self, video_id, privacy="public"):
        """تغيير الخصوصية فقط (للنشر بعد المعاينة بأمر صريح من المالك)."""
        v = self.get("videos", part="status", id=video_id).get("items", [])
        if not v:
            raise RuntimeError(f"الفيديو {video_id} غير موجود")
        st = v[0]["status"]
        body = {"id": video_id, "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": st.get("madeForKids", False),
                                          "license": st.get("license", "youtube"), "embeddable": st.get("embeddable", True),
                                          "publicStatsViewable": st.get("publicStatsViewable", True)}}
        self._req("PUT", f"{API}/videos", {"part": "status"}, body=body)
        return self.get("videos", part="status", id=video_id)["items"][0]["status"]

    def video_status(self, video_id):
        items = self.get("videos", part="status,processingDetails,snippet,contentDetails,statistics", id=video_id).get("items", [])
        return items[0] if items else None

    def wait_processed(self, video_id, timeout=1800, log=print):
        t0 = time.time()
        while time.time() - t0 < timeout:
            v = self.video_status(video_id)
            if not v:
                time.sleep(15)
                continue
            st = v["status"].get("uploadStatus")
            if st in ("processed",):
                return v
            if st in ("failed", "rejected", "deleted"):
                raise RuntimeError(f"فشلت معالجة يوتيوب: {st} {v['status'].get('failureReason') or v['status'].get('rejectionReason') or ''}")
            time.sleep(20)
        return self.video_status(video_id)

    def recent_uploads(self, n=50):
        ch = self.my_channel()
        pl = ch["contentDetails"]["relatedPlaylists"]["uploads"]
        ids = [i["contentDetails"]["videoId"] for i in self.get("playlistItems", part="contentDetails", playlistId=pl, maxResults=min(50, n)).get("items", [])]
        if not ids:
            return []
        return self.get("videos", part="snippet,status,contentDetails,statistics", id=",".join(ids)).get("items", [])

    # ---------- التحليلات ----------
    def report(self, start, end, metrics, dimensions=None, filters=None, sort=None, max_results=None):
        p = {"ids": "channel==MINE", "startDate": start, "endDate": end, "metrics": metrics}
        if dimensions: p["dimensions"] = dimensions
        if filters: p["filters"] = filters
        if sort: p["sort"] = sort
        if max_results: p["maxResults"] = max_results
        r = self._req("GET", ANALYTICS, p)
        cols = [c["name"] for c in r.get("columnHeaders", [])]
        return [dict(zip(cols, row)) for row in r.get("rows", []) or []]
