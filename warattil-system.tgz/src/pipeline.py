#!/usr/bin/env python3
"""خط الإنتاج: ملف صوتي ← فحص ← تحسين ← فيديو أفقي + مقطع عمودي ← صورة مصغرة وبيانات ← مراجعة جودة ← رفع وجدولة ← سجل.

الاستخدام:
  python3 src/pipeline.py process <ملف_صوتي> [--name "يس 1-12"] [--no-upload]
  python3 src/pipeline.py upload <مجلد_المهمة>      # رفع مهمة جاهزة لم تُرفع بعد
  python3 src/pipeline.py status                     # حالة كل المهام
رموز الخروج: 0 نجاح | 3 تحتاج معلومات (السورة/الآيات) | 4 مشكلة في الصوت | 5 فشل جودة | 6 فشل رفع/صلاحيات
"""
import argparse, datetime as dt, hashlib, json, shutil, subprocess, sys, traceback
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parent))
import audio, brand, meta, video, youtube  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
JOBS = ROOT / "jobs"
LOG = ROOT / "logs" / "videos.jsonl"


def cfg():
    return json.loads((ROOT / "config.json").read_text(encoding="utf-8"))


class Job:
    def __init__(self, d):
        self.dir = Path(d).resolve()
        self.dir.mkdir(parents=True, exist_ok=True)
        f = self.dir / "job.json"
        self.data = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {"log": [], "status": "new"}

    def log(self, step, msg, level="info"):
        e = {"t": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), "step": step, "level": level, "msg": msg}
        self.data["log"].append(e)
        print(f"[{step}] {msg}", flush=True)
        self.save()

    def set(self, **kw):
        self.data.update(kw)
        self.save()

    def save(self):
        (self.dir / "job.json").write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def append_log(job):
    LOG.parent.mkdir(exist_ok=True)
    d = job.data
    row = {k: d.get(k) for k in ("job_id", "status", "source_name", "source_sha256", "surah", "surah_name", "ayah_from", "ayah_to",
                                 "duration", "long", "short", "warnings", "error")}
    row["t"] = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


# ------------------------------------------------------------------ الإنتاج

def produce(src, name=None, reciter=None, job_dir=None):
    c = cfg()
    if reciter is not None:
        c["channel"]["reciter_name"] = reciter
    src = Path(src)
    stamp = dt.datetime.now(ZoneInfo(c["publish"]["timezone"])).strftime("%Y%m%d-%H%M%S")
    job = Job(job_dir or JOBS / f"{stamp}")
    job.set(job_id=job.dir.name, source_name=(name or src.name), status="processing", warnings=[])

    # 0) حفظ الأصل كما هو (للقراءة فقط) — لا يُستبدل أبدًا
    orig = job.dir / f"original{src.suffix.lower() or '.audio'}"
    if not orig.exists():
        shutil.copy2(src, orig)
        orig.chmod(0o444)
    job.set(source_sha256=sha256(orig))
    job.log("original", f"حُفظ الملف الأصلي ({orig.stat().st_size / 1e6:.1f}MB)، sha256={job.data['source_sha256'][:12]}…")

    # 1) السورة والآيات — من الاسم الذي كتبه القارئ فقط، مع التحقق من حدود السورة
    info = meta.parse_name(name or src.name)
    # التعرّف الصوتي ومطابقة المصحف: يحدد السورة إن لم تُذكر، ويتحقق منها إن ذُكرت
    ident = None
    try:
        import identify
        if Path(identify.ROOT / "models" / "sherpa-onnx-whisper-small").exists():
            quran, words = identify.load_quran()
            ident = identify.summarize(identify.refine(identify.match(identify.transcribe(orig, identify.ROOT / "models" / "sherpa-onnx-whisper-small"), words), words), quran)
            job.set(identification=ident)
            job.log("identify", f"التعرّف الصوتي: سورة {ident.get('surah_name')} {ident.get('ayah_from')}-{ident.get('ayah_to')}، "
                                f"الثقة {ident.get('confidence')}، المقاطع المطابقة {ident.get('chunks_matched')}" if ident.get("surah") else ident.get("reason", ""))
    except Exception as e:
        job.log("identify", f"تعذر التعرّف الصوتي: {e}", "warn")
    if ident and ident.get("identified"):
        if not info:
            info = meta._validate(meta.surah_by_number(ident["surah"]), ident["ayah_from"], ident["ayah_to"])
            job.log("meta", "حُددت السورة والآيات من التلاوة نفسها بعد مطابقتها مع نص المصحف")
        elif info["surah"] != ident["surah"]:
            info = {**info, "errors": [f"الاسم المكتوب (سورة {info['surah_name']}) يخالف ما في التسجيل (سورة {ident['surah_name']} "
                                       f"{ident['ayah_from']}-{ident['ayah_to']})"]}
    if not info or info["errors"]:
        why = info["errors"][0] if info and info["errors"] else "لم يُذكر اسم السورة في اسم الملف أو الرسالة"
        job.set(status="needs_info", error=why)
        job.log("meta", why + " — لن يُنشر شيء دون التحقق من السورة والآيات", "error")
        append_log(job)
        return job, 3
    info["reciter"] = c["channel"].get("reciter_name", "")
    job.set(**{k: info[k] for k in ("surah", "surah_name", "ayah_from", "ayah_to", "full_surah")})
    rng = f" {info['ayah_from']}-{info['ayah_to']}" if info["ayah_from"] else " (دون تحديد آيات)"
    job.log("meta", f"السورة: {info['surah_name']} ({info['surah']}){rng} — مطابقة لعدد آيات السورة ({info['surah_ayahs']})")

    # 2) فحص الصوت
    an = audio.analyze(orig)
    job.set(analysis={k: an[k] for k in ("duration", "codec", "sample_rate", "channels", "lufs", "lra", "true_peak", "peak_db",
                                          "noise_floor_db", "voice_level_db", "snr_db", "samples_at_0db", "speech_ratio")},
            duration=round(an["duration"], 2))
    job.log("analyze", f"المدة {an['duration'] / 60:.1f} د، الجهارة {an['lufs']:.1f} LUFS، الذروة {an['true_peak']:.1f} dBTP، "
                       f"نسبة الصوت للضوضاء {an['snr_db']:.0f} dB، وقفات مكتشفة {len(an['silences'])}")
    for w in an["warnings"]:
        job.data["warnings"].append(w)
        job.log("analyze", w, "warn")
    if an["issues"]:
        job.set(status="audio_rejected", error="؛ ".join(an["issues"]))
        job.log("analyze", job.data["error"], "error")
        append_log(job)
        return job, 4

    # 3) التحسين (نسخة منفصلة؛ الأصل لا يُمس)
    enh = job.dir / "enhanced.m4a"
    r = audio.enhance(orig, enh, an, c["audio"]["target_lufs"], c["audio"].get("denoise", True))
    for a in r["applied"]:
        job.log("enhance", a)
    an2 = audio.analyze(enh)
    job.set(enhanced={"lufs": an2["lufs"], "true_peak": an2["true_peak"], "duration": round(an2["duration"], 2)})

    # 4) الرسوم
    out = job.dir / "out"
    text_h = brand.video_layers(info, out, vertical=False)
    thumb_png = brand.thumbnail(info, out / "thumb.png")
    thumb = out / "thumb.jpg"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(thumb_png), "-q:v", "2", str(thumb)], check=True)
    job.log("design", "تم إنشاء طبقة النص والصورة المصغرة")

    # 5) الفيديو الأفقي
    m_long = meta.build(info, c, "long")
    long_mp4 = out / f"{m_long['file_stem']}.mp4"
    video.render(text_h, enh, long_mp4, fps=c["video"]["fps"], crf=c["video"]["crf"])
    q = video.qa(long_mp4, an2["duration"])
    job.set(long={"file": str(long_mp4.relative_to(ROOT)), "qa": q, "meta": m_long, "thumb": str(thumb.relative_to(ROOT))})
    if not q["ok"]:
        job.set(status="qa_failed", error="؛ ".join(q["problems"]))
        job.log("qa", "فشل فحص الجودة للفيديو الأفقي: " + job.data["error"], "error")
        append_log(job)
        return job, 5
    job.log("qa", f"الفيديو الأفقي سليم: {q['width']}x{q['height']}، {q['duration'] / 60:.1f} د، {q['size_mb']}MB، الصوت والصورة متزامنان")

    # 6) المقطع العمودي (عند المناسبة فقط، ويُقص عند وقفة طبيعية)
    if c["video"]["make_shorts"]:
        seg = audio.short_segment(an2, c["video"]["short_max_seconds"], c["video"]["short_min_seconds"])
        if not seg:
            job.log("short", "لم يُنشأ مقطع قصير: لا توجد وقفة طبيعية مناسبة قبل الحد الأقصى للمدة", "warn")
        else:
            s_info = dict(info)
            if seg[1] < an2["duration"] - 0.5:  # مقطع جزئي ⇒ لا نذكر نطاق آيات لم نتحقق منه
                s_info.update(ayah_from=None, ayah_to=None, full_surah=False, partial=True)
            text_v = brand.video_layers(s_info, out, vertical=True)
            m_short = meta.build(s_info, c, "short")
            short_mp4 = out / f"{m_short['file_stem']}.mp4"
            video.render(text_v, enh, short_mp4, vertical=True, start=seg[0], dur=seg[1] - seg[0], fps=c["video"]["fps"], crf=c["video"]["crf"])
            qs = video.qa(short_mp4, seg[1] - seg[0], vertical=True)
            job.set(short={"file": str(short_mp4.relative_to(ROOT)), "qa": qs, "meta": m_short, "segment": seg})
            if qs["ok"]:
                job.log("short", f"مقطع عمودي 9:16 مدته {seg[1] - seg[0]:.0f}ث ينتهي عند وقفة طبيعية")
            else:
                job.data["warnings"].append("فشل فحص جودة المقطع القصير: " + "؛ ".join(qs["problems"]))
                job.data.pop("short")
                job.log("short", job.data["warnings"][-1], "warn")
    job.set(status="ready")
    return job, 0


# ------------------------------------------------------------------ الجدولة والرفع

def next_slot(yt, c, kind, taken_extra=(), not_before=None):
    tz = ZoneInfo(c["publish"]["timezone"])
    hh, mm = map(int, c["publish"]["long_slot" if kind == "long" else "short_slot"].split(":"))
    taken = set(taken_extra)
    for v in yt.recent_uploads(50):
        is_short = "#Shorts" in v["snippet"].get("description", "") or "#shorts" in v["snippet"].get("title", "").lower()
        if (kind == "short") != is_short:
            continue
        when = v["status"].get("publishAt") or (v["snippet"].get("publishedAt") if v["status"].get("privacyStatus") == "public" else None)
        if when:
            taken.add(dt.datetime.fromisoformat(when.replace("Z", "+00:00")).astimezone(tz).date())
    now = dt.datetime.now(tz)
    if not_before and not_before > now:
        now = not_before
    day = now.date()
    for _ in range(400):
        t = dt.datetime(day.year, day.month, day.day, hh, mm, tzinfo=tz)
        if t >= now + dt.timedelta(hours=c["publish"]["min_lead_hours"]) and day not in taken:
            return t
        day += dt.timedelta(days=1)
    raise RuntimeError("لا يوجد موعد نشر متاح")


def _status(c, when):
    mode = c["publish"]["mode"]
    st = {"selfDeclaredMadeForKids": c["publish"]["made_for_kids"], "license": c["publish"]["license"], "embeddable": True,
          "publicStatsViewable": True, "containsSyntheticMedia": False}
    if mode == "public":
        st["privacyStatus"] = "public"
    elif mode == "schedule":
        st["privacyStatus"] = "private"
        st["publishAt"] = when.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    else:
        st["privacyStatus"] = "private"
    return st


def upload(job):
    c = cfg()
    if not youtube.configured():
        job.set(status="ready_not_uploaded", error="ربط يوتيوب غير مكتمل بعد")
        job.log("upload", "الفيديو جاهز لكن لم يُرفع: ربط يوتيوب غير مكتمل", "warn")
        return 6
    yt = youtube.YouTube()
    try:
        ch = yt.my_channel()
        chan_url = f"https://www.youtube.com/{ch['snippet'].get('customUrl') or 'channel/' + ch['id']}"
        brand_name = c["channel"]["name_ar"]
        d = job.data
        info = {"surah": d["surah"], "surah_name": d["surah_name"]}
        cache = {p["snippet"]["title"]: p["id"] for p in yt.playlists()}
        pl_surah = yt.ensure_playlist(f"سورة {d['surah_name']} | {brand_name}", f"تلاوات من سورة {d['surah_name']} على قناة {brand_name}.", cache=cache)
        pl_all = yt.ensure_playlist(f"جميع التلاوات | {brand_name}", f"كل التلاوات المنشورة على قناة {brand_name} مرتبة حسب النشر.", cache=cache)
        pl_short = yt.ensure_playlist(f"مقاطع قصيرة | {brand_name}", "مقاطع قصيرة من التلاوات.", cache=cache)

        # الفيديو الطويل
        L = d["long"]
        if not L.get("video_id"):
            # منع التكرار: نفس العنوان مرفوع مسبقًا؟
            dup = next((v for v in yt.recent_uploads(50) if v["snippet"]["title"] == L["meta"]["title"]), None)
            if dup:
                job.log("upload", f"تنبيه: يوجد فيديو بالعنوان نفسه مسبقًا ({dup['id']}) — أُوقف الرفع لتجنب التكرار", "error")
                job.set(status="duplicate", error=f"عنوان مكرر مع https://youtu.be/{dup['id']}")
                return 6
            when = next_slot(yt, c, "long")
            m = meta.build({**meta._validate(meta.surah_by_number(d["surah"]), d.get("ayah_from"), d.get("ayah_to"), d.get("full_surah")),
                            "reciter": c["channel"].get("reciter_name", "")}, c, "long",
                           {"channel": chan_url, "playlist": f"https://www.youtube.com/playlist?list={pl_surah}"})
            snippet = {"title": m["title"], "description": m["description"], "tags": m["tags"], "categoryId": c["publish"]["category_id"],
                       "defaultLanguage": "ar", "defaultAudioLanguage": "ar"}
            job.log("upload", f"رفع الفيديو الأفقي: {m['title']}")
            r = yt.upload(ROOT / L["file"], snippet, _status(c, when), log=lambda s: job.log("upload", s))
            L.update(video_id=r["id"], url=f"https://youtu.be/{r['id']}", title=m["title"], publish_mode=c["publish"]["mode"],
                     publish_at=when.isoformat() if c["publish"]["mode"] == "schedule" else None)
            job.set(long=L, status="uploading")
            job.log("upload", f"اكتمل الرفع: {L['url']}")
        try:
            yt.set_thumbnail(L["video_id"], ROOT / L["thumb"])
            job.log("thumbnail", "تم رفع الصورة المصغرة")
        except youtube.YTError as e:
            msg = "تعذر رفع الصورة المصغرة — غالبًا يلزم توثيق القناة برقم الجوال (youtube.com/verify)" if e.code == 403 else str(e)
            job.data["warnings"].append(msg)
            job.log("thumbnail", msg, "warn")
        for pl in (pl_surah, pl_all):
            yt.add_to_playlist(pl, L["video_id"])
        job.log("playlist", "أُضيف إلى قائمة السورة وقائمة جميع التلاوات")
        v = yt.wait_processed(L["video_id"], log=lambda s: job.log("processing", s))
        L["processing"] = v["status"].get("uploadStatus") if v else "unknown"
        L["privacy"] = v["status"].get("privacyStatus") if v else None
        job.set(long=L)
        job.log("processing", f"حالة المعالجة في يوتيوب: {L['processing']}، الخصوصية: {L['privacy']}")

        # المقطع القصير — يُجدول في يوم لاحق ويربط بالفيديو الكامل
        S = d.get("short")
        if S and not S.get("video_id"):
            # المقطع القصير يُنشر بعد الفيديو الكامل (في اليوم التالي على الأقل) ليشير إليه
            base = dt.datetime.fromisoformat(L["publish_at"]) if L.get("publish_at") else None
            when_s = next_slot(yt, c, "short", not_before=base + dt.timedelta(hours=12) if base else None)
            s_info = {**meta._validate(meta.surah_by_number(d["surah"]), None, None), "reciter": c["channel"].get("reciter_name", "")}
            m = meta.build(s_info, c, "short", {"channel": chan_url, "full_video": L["url"]})
            snippet = {"title": m["title"], "description": m["description"], "tags": m["tags"], "categoryId": c["publish"]["category_id"],
                       "defaultLanguage": "ar", "defaultAudioLanguage": "ar"}
            r = yt.upload(ROOT / S["file"], snippet, _status(c, when_s), log=lambda s: job.log("upload", s))
            S.update(video_id=r["id"], url=f"https://youtu.be/{r['id']}", title=m["title"],
                     publish_at=when_s.isoformat() if c["publish"]["mode"] == "schedule" else None)
            yt.add_to_playlist(pl_short, r["id"])
            job.set(short=S)
            job.log("upload", f"رُفع المقطع القصير: {S['url']}")
        final = {"schedule": "scheduled", "public": "published", "private": "uploaded_private"}[c["publish"]["mode"]]
        job.set(status=final, error=None)
        return 0
    except Exception as e:
        job.set(status="upload_failed", error=str(e)[:500])
        job.log("upload", f"فشل: {e}", "error")
        traceback.print_exc()
        return 6
    finally:
        append_log(job)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("process"); p.add_argument("audio"); p.add_argument("--name"); p.add_argument("--reciter")
    p.add_argument("--no-upload", action="store_true"); p.add_argument("--job-dir")
    u = sub.add_parser("upload"); u.add_argument("job_dir")
    sub.add_parser("status")
    a = ap.parse_args()
    if a.cmd == "process":
        job, code = produce(a.audio, a.name, a.reciter, a.job_dir)
        if code == 0 and not a.no_upload:
            code = upload(job)
        elif code == 0:
            append_log(job)
        print(json.dumps({"job": str(job.dir), "status": job.data["status"], "exit": code, "error": job.data.get("error"),
                          "warnings": job.data.get("warnings"), "long": (job.data.get("long") or {}).get("url"),
                          "short": (job.data.get("short") or {}).get("url")}, ensure_ascii=False))
        sys.exit(code)
    if a.cmd == "upload":
        job = Job(a.job_dir)
        sys.exit(upload(job))
    if a.cmd == "status":
        for j in sorted(JOBS.glob("*/job.json")):
            d = json.loads(j.read_text(encoding="utf-8"))
            print(d.get("job_id"), d.get("status"), d.get("surah_name"), d.get("ayah_from"), d.get("ayah_to"),
                  (d.get("long") or {}).get("url", ""), d.get("error") or "")


if __name__ == "__main__":
    main()
